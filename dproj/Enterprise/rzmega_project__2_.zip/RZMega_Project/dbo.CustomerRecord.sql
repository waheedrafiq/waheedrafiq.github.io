﻿CREATE TABLE [dbo].[Table]
(
	[CustomerREF] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Fname] NCHAR(200) NULL, 
    [Surname] NCHAR(200) NULL, 
    [FullAddress] NCHAR(500) NULL, 
    [PostCode] NCHAR(100) NULL, 
    [Telephone] NCHAR(100) NULL, 
    [Email] NCHAR(200) NULL
)
