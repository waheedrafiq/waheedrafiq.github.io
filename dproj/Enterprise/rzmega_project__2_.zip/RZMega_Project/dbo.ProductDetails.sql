﻿CREATE TABLE [dbo].[tbl_ProductDetails]
(
	[ProductID] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Product_Name] NCHAR(200) NULL, 
    [Product_Description] NCHAR(500) NULL, 
    [Product_Price] MONEY NULL
)
