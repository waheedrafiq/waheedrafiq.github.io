﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmMain
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            frmCustomerRecord disFRM = new frmCustomerRecord();
            disFRM.Show();
            this.Hide();

        }

        private void btnProductDetails_Click(object sender, EventArgs e)
        {
            frmProductDetails disProductDetails = new frmProductDetails();
            disProductDetails.Show();
            this.Hide();

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnGenerateInvoice_Click(object sender, EventArgs e)
        {
            //frmShoppingList genInvoice = new frmShoppingList
           // this.Hide();

            GenerateInvoice genInvoice = new GenerateInvoice();
            genInvoice.Show();
            this.Hide();

            
        }
    }
}
