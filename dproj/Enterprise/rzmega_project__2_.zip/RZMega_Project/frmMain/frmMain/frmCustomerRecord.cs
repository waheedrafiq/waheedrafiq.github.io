﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmMain
{
    public partial class frmCustomerRecord : Form
    {
        public frmCustomerRecord()
        {
            InitializeComponent();
        }

        DatabaseConnection objConnect;
        string conString;

        DataSet ds;
        DataRow dRow;

        int MaxRows;
        int inc = 0;


        private void frmCustomerRecord_Load(object sender, EventArgs e)
        {
            try
            {
                objConnect = new DatabaseConnection();
               // conString = Properties.Settings.Default.RZDatabaseConnectionString;
                conString = "Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|/RZDatabase.mdf;Integrated Security=True";

                objConnect.connection_string = conString;
                //objConnect.Sql = Properties.Settings.Default.SQL;
                objConnect.Sql = "Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|/RZDatabase.mdf;Integrated Security=True";

                ds = objConnect.GetConnection;
                MaxRows = ds.Tables[0].Rows.Count;

                NavigateRecords();
                labelUpdate();



            }
            catch(Exception err)
            {

                MessageBox.Show(err.Message);
            }
        }
        private void NavigateRecords()
        {
            dRow = ds.Tables[0].Rows[inc];

            txtFname.Text = dRow.ItemArray.GetValue(1).ToString();
         
            txtFullAddress.Text = dRow.ItemArray.GetValue(2).ToString();
            txtPostCode.Text = dRow.ItemArray.GetValue(3).ToString();
            txtTelephone.Text = dRow.ItemArray.GetValue(4).ToString();
            txtEmail.Text = dRow.ItemArray.GetValue(5).ToString();


        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if(inc != MaxRows -1 )
            {
                inc++;
                NavigateRecords();
                labelUpdate();
            }
            else
            {
                MessageBox.Show("No More Records ");
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if(inc > 0)
            {
                inc--;
                NavigateRecords();
                labelUpdate();


            }
            else
            {
                MessageBox.Show("First Record");
            }
        }

        private void btnLastRecord_Click(object sender, EventArgs e)
        {

            if(inc!=MaxRows -1)
            {
                inc = MaxRows - 1;
                NavigateRecords();
                labelUpdate();
                MessageBox.Show("Last Record in database");
            }
        }

        private void btnFirstRecord_Click(object sender, EventArgs e)
        {
            inc = 0;
            NavigateRecords();
            labelUpdate();
            MessageBox.Show("First Record in Database");
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
           
            //Clear text boxes 

            txtFname.Clear();
         
            txtFullAddress.Clear();
            txtPostCode.Clear();
            txtTelephone.Clear();
            txtEmail.Clear();

            btnAddNew.Enabled = false;
            btnSave.Enabled = true;
            btnCancel.Enabled = true;
            btnUpdate.Enabled = false;


        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            NavigateRecords();
            labelUpdate();
            btnCancel.Enabled = false;
            btnSave.Enabled = false;
            btnAddNew.Enabled = true;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DataRow row = ds.Tables[0].NewRow();
            row[1] = txtFname.Text;
            row[2] = txtFullAddress.Text;
            row[3] = txtPostCode.Text;
            row[4] = txtTelephone.Text;
            row[5] = txtEmail.Text;

            ds.Tables[0].Rows.Add(row);

            try
            {
                objConnect.UpdateDatabase(ds);
                MaxRows=MaxRows + 1;
                inc = MaxRows - 1;

                MessageBox.Show("Database updated");                    

            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message);
            }

            btnCancel.Enabled = false;
            btnSave.Enabled = false;
            btnAddNew.Enabled = true;
            btnUpdate.Enabled = true;

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            FrmMain returnMenu = new FrmMain();

            returnMenu.Show();
            this.Hide();


            

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            DataRow row = ds.Tables[0].Rows[inc];

            row[1] = txtFname.Text;
       
            row[2] = txtFullAddress.Text;
            row[3] = txtPostCode.Text;
            row[4] = txtTelephone.Text;
            row[5] = txtEmail.Text;


            try
            {
                objConnect.UpdateDatabase(ds);

                MessageBox.Show("Record Updated");
                labelUpdate();


            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message);

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ds.Tables[0].Rows[inc].Delete();
                objConnect.UpdateDatabase(ds);

                MaxRows = ds.Tables[0].Rows.Count;
                inc--;
                NavigateRecords();
                labelUpdate();

                MessageBox.Show("Record Deleted");

            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message);

            }
        }

        private void labelUpdate()
        {
            lblRecordUpdate.Text = "Record " + (inc + 1) + "  of  " + MaxRows;

        }
        private void lblRecordUpdate_Click(object sender, EventArgs e)
        {
            
        }

        
    }
    
}
 