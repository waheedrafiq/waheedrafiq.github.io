﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;


namespace frmMain
{
    class GeneralClass
    {
        public void Subtotal()
        {
            ArrayList SubtotalList = new ArrayList();
            


        }

    }
}
