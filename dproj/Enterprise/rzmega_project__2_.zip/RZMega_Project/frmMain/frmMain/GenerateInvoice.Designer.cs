﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;

namespace frmMain
{
    partial class GenerateInvoice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GenerateInvoice));
            this.tblCustomerRecordBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.ds_CustomerRecords = new frmMain.ds_CustomerRecords();
            this.tblCustomerRecordBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_CustomerRecordTableAdapter = new frmMain.ds_CustomerRecordsTableAdapters.tbl_CustomerRecordTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.LstProductPrice = new System.Windows.Forms.ListBox();
            this.tblProductDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rZGenerateInvoiceDS = new frmMain.RZGenerateInvoiceDS();
           this.tbl_ProductDetailsTableAdapter = new frmMain.RZGenerateInvoiceDSTableAdapters.tbl_ProductDetailsTableAdapter();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.tbl_ProductDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_ProductDetailsTableAdapter1 = new frmMain.ds_CustomerRecordsTableAdapters.tbl_ProductDetailsTableAdapter();
           this.tableAdapterManager = new frmMain.ds_CustomerRecordsTableAdapters.TableAdapterManager();
            this.tbl_ProductDetailsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblProductPrice = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.lblYourOrder = new System.Windows.Forms.Label();
            this.LstQty = new System.Windows.Forms.ListBox();
            this.LstTotal = new System.Windows.Forms.ListBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnAddToList = new System.Windows.Forms.Button();
            this.lblSubTotal = new System.Windows.Forms.Label();
            this.btnInvoice = new System.Windows.Forms.Button();
            this.rZDatabaseDataSet1 = new frmMain.RZDatabaseDataSet1();
            this.tblCustomerRecordBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
           this.tbl_CustomerRecordTableAdapter1 = new frmMain.RZDatabaseDataSet1TableAdapters.tbl_CustomerRecordTableAdapter();
            this.tbl_CustomerDetailsDataGridView = new System.Windows.Forms.DataGridView();
            this.fnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fullAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.postCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.tblCustomerRecordBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_CustomerRecords)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCustomerRecordBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblProductDetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rZGenerateInvoiceDS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_ProductDetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_ProductDetailsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rZDatabaseDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCustomerRecordBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_CustomerDetailsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // tblCustomerRecordBindingSource1
            // 
            this.tblCustomerRecordBindingSource1.DataMember = "tbl_CustomerRecord";
            this.tblCustomerRecordBindingSource1.DataSource = this.ds_CustomerRecords;
            // 
            // ds_CustomerRecords
            // 
            this.ds_CustomerRecords.DataSetName = "ds_CustomerRecords";
            this.ds_CustomerRecords.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblCustomerRecordBindingSource
            // 
            this.tblCustomerRecordBindingSource.DataMember = "tbl_CustomerRecord";
            this.tblCustomerRecordBindingSource.DataSource = this.ds_CustomerRecords;
            // 
            // tbl_CustomerRecordTableAdapter
            // 
            this.tbl_CustomerRecordTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.Location = new System.Drawing.Point(967, 300);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 76);
            this.button1.TabIndex = 6;
            this.button1.Text = "&Return to Main";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // LstProductPrice
            // 
            this.LstProductPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.LstProductPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LstProductPrice.FormattingEnabled = true;
            this.LstProductPrice.ItemHeight = 25;
            this.LstProductPrice.Location = new System.Drawing.Point(285, 287);
            this.LstProductPrice.Name = "LstProductPrice";
            this.LstProductPrice.Size = new System.Drawing.Size(165, 129);
            this.LstProductPrice.TabIndex = 7;
            this.LstProductPrice.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // tblProductDetailsBindingSource
            // 
            this.tblProductDetailsBindingSource.DataMember = "tbl_ProductDetails";
            this.tblProductDetailsBindingSource.DataSource = this.rZGenerateInvoiceDS;
            // 
            // rZGenerateInvoiceDS
            // 
            this.rZGenerateInvoiceDS.DataSetName = "RZGenerateInvoiceDS";
            this.rZGenerateInvoiceDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_ProductDetailsTableAdapter
            // 
            this.tbl_ProductDetailsTableAdapter.ClearBeforeFill = true;
            // 
            // txtQty
            // 
            this.txtQty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.txtQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQty.ForeColor = System.Drawing.Color.Blue;
            this.txtQty.Location = new System.Drawing.Point(837, 300);
            this.txtQty.Multiline = true;
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(112, 76);
            this.txtQty.TabIndex = 14;
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantity.Location = new System.Drawing.Point(850, 250);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(85, 25);
            this.lblQuantity.TabIndex = 15;
            this.lblQuantity.Text = "Quantity";
            // 
            // tbl_ProductDetailsBindingSource
            // 
            this.tbl_ProductDetailsBindingSource.DataMember = "tbl_ProductDetails";
            this.tbl_ProductDetailsBindingSource.DataSource = this.ds_CustomerRecords;
            // 
            // tbl_ProductDetailsTableAdapter1
            // 
            this.tbl_ProductDetailsTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tbl_CustomerRecordTableAdapter = this.tbl_CustomerRecordTableAdapter;
            this.tableAdapterManager.tbl_ProductDetailsTableAdapter = this.tbl_ProductDetailsTableAdapter1;
            this.tableAdapterManager.UpdateOrder = frmMain.ds_CustomerRecordsTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tbl_ProductDetailsDataGridView
            // 
            this.tbl_ProductDetailsDataGridView.AllowUserToAddRows = false;
            this.tbl_ProductDetailsDataGridView.AllowUserToDeleteRows = false;
            this.tbl_ProductDetailsDataGridView.AllowUserToResizeColumns = false;
            this.tbl_ProductDetailsDataGridView.AllowUserToResizeRows = false;
            this.tbl_ProductDetailsDataGridView.AutoGenerateColumns = false;
            this.tbl_ProductDetailsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tbl_ProductDetailsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.tbl_ProductDetailsDataGridView.DataSource = this.tbl_ProductDetailsBindingSource;
            this.tbl_ProductDetailsDataGridView.Location = new System.Drawing.Point(12, 12);
            this.tbl_ProductDetailsDataGridView.Name = "tbl_ProductDetailsDataGridView";
            this.tbl_ProductDetailsDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders;
            this.tbl_ProductDetailsDataGridView.RowTemplate.Height = 24;
            this.tbl_ProductDetailsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tbl_ProductDetailsDataGridView.Size = new System.Drawing.Size(444, 220);
            this.tbl_ProductDetailsDataGridView.TabIndex = 17;
            this.tbl_ProductDetailsDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tbl_ProductDetailsDataGridView_CellContentClick);
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Product_Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Product_Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Product_Description";
            this.dataGridViewTextBoxColumn3.HeaderText = "Product_Description";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Product_Price";
            this.dataGridViewTextBoxColumn4.HeaderText = "Product_Price";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // lblProductPrice
            // 
            this.lblProductPrice.AutoSize = true;
            this.lblProductPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductPrice.Location = new System.Drawing.Point(280, 250);
            this.lblProductPrice.Name = "lblProductPrice";
            this.lblProductPrice.Size = new System.Drawing.Size(134, 25);
            this.lblProductPrice.TabIndex = 18;
            this.lblProductPrice.Text = "Product Price:";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.Location = new System.Drawing.Point(474, 250);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(119, 25);
            this.lblPrice.TabIndex = 20;
            this.lblPrice.Text = "Order items:";
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 25;
            this.listBox1.Location = new System.Drawing.Point(21, 287);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(211, 129);
            this.listBox1.TabIndex = 22;
            // 
            // lblYourOrder
            // 
            this.lblYourOrder.AutoSize = true;
            this.lblYourOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYourOrder.Location = new System.Drawing.Point(16, 250);
            this.lblYourOrder.Name = "lblYourOrder";
            this.lblYourOrder.Size = new System.Drawing.Size(124, 25);
            this.lblYourOrder.TabIndex = 23;
            this.lblYourOrder.Text = "Your Order : ";
            // 
            // LstQty
            // 
            this.LstQty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.LstQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LstQty.FormattingEnabled = true;
            this.LstQty.ItemHeight = 25;
            this.LstQty.Location = new System.Drawing.Point(469, 287);
            this.LstQty.Name = "LstQty";
            this.LstQty.Size = new System.Drawing.Size(165, 129);
            this.LstQty.TabIndex = 24;
            // 
            // LstTotal
            // 
            this.LstTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.LstTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LstTotal.FormattingEnabled = true;
            this.LstTotal.ItemHeight = 25;
            this.LstTotal.Location = new System.Drawing.Point(661, 287);
            this.LstTotal.Name = "LstTotal";
            this.LstTotal.Size = new System.Drawing.Size(165, 129);
            this.LstTotal.TabIndex = 25;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(656, 250);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(67, 25);
            this.lblTotal.TabIndex = 26;
            this.lblTotal.Text = "Total :";
            // 
            // btnAddToList
            // 
            this.btnAddToList.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddToList.Image = ((System.Drawing.Image)(resources.GetObject("btnAddToList.Image")));
            this.btnAddToList.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAddToList.Location = new System.Drawing.Point(924, 12);
            this.btnAddToList.Name = "btnAddToList";
            this.btnAddToList.Size = new System.Drawing.Size(156, 92);
            this.btnAddToList.TabIndex = 27;
            this.btnAddToList.Text = "Add to List";
            this.btnAddToList.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAddToList.UseVisualStyleBackColor = true;
            this.btnAddToList.Click += new System.EventHandler(this.btnAddToList_Click);
            // 
            // lblSubTotal
            // 
            this.lblSubTotal.AutoSize = true;
            this.lblSubTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubTotal.Location = new System.Drawing.Point(832, 391);
            this.lblSubTotal.Name = "lblSubTotal";
            this.lblSubTotal.Size = new System.Drawing.Size(103, 25);
            this.lblSubTotal.TabIndex = 28;
            this.lblSubTotal.Text = "Sub Total:";
            // 
            // btnInvoice
            // 
            this.btnInvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInvoice.Image = ((System.Drawing.Image)(resources.GetObject("btnInvoice.Image")));
            this.btnInvoice.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnInvoice.Location = new System.Drawing.Point(924, 110);
            this.btnInvoice.Name = "btnInvoice";
            this.btnInvoice.Size = new System.Drawing.Size(156, 119);
            this.btnInvoice.TabIndex = 29;
            this.btnInvoice.Text = "Generate";
            this.btnInvoice.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnInvoice.UseVisualStyleBackColor = true;
            this.btnInvoice.Click += new System.EventHandler(this.btnInvoice_Click);
            // 
            // rZDatabaseDataSet1
            // 
            this.rZDatabaseDataSet1.DataSetName = "RZDatabaseDataSet1";
            this.rZDatabaseDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblCustomerRecordBindingSource2
            // 
            this.tblCustomerRecordBindingSource2.DataMember = "tbl_CustomerRecord";
            this.tblCustomerRecordBindingSource2.DataSource = this.rZDatabaseDataSet1;
            // 
            // tbl_CustomerRecordTableAdapter1
            // 
            this.tbl_CustomerRecordTableAdapter1.ClearBeforeFill = true;
            // 
            // tbl_CustomerDetailsDataGridView
            // 
            this.tbl_CustomerDetailsDataGridView.AutoGenerateColumns = false;
            this.tbl_CustomerDetailsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tbl_CustomerDetailsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.fnameDataGridViewTextBoxColumn,
            this.fullAddressDataGridViewTextBoxColumn,
            this.postCodeDataGridViewTextBoxColumn});
            this.tbl_CustomerDetailsDataGridView.DataSource = this.tblCustomerRecordBindingSource;
            this.tbl_CustomerDetailsDataGridView.Location = new System.Drawing.Point(469, 12);
            this.tbl_CustomerDetailsDataGridView.Name = "tbl_CustomerDetailsDataGridView";
            this.tbl_CustomerDetailsDataGridView.RowTemplate.Height = 24;
            this.tbl_CustomerDetailsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tbl_CustomerDetailsDataGridView.Size = new System.Drawing.Size(439, 217);
            this.tbl_CustomerDetailsDataGridView.TabIndex = 31;
            this.tbl_CustomerDetailsDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tbl_CustomerDetailsDataGridView_CellContentClick);
            // 
            // fnameDataGridViewTextBoxColumn
            // 
            this.fnameDataGridViewTextBoxColumn.DataPropertyName = "Fname";
            this.fnameDataGridViewTextBoxColumn.HeaderText = "Fname";
            this.fnameDataGridViewTextBoxColumn.Name = "fnameDataGridViewTextBoxColumn";
            // 
            // fullAddressDataGridViewTextBoxColumn
            // 
            this.fullAddressDataGridViewTextBoxColumn.DataPropertyName = "FullAddress";
            this.fullAddressDataGridViewTextBoxColumn.HeaderText = "FullAddress";
            this.fullAddressDataGridViewTextBoxColumn.Name = "fullAddressDataGridViewTextBoxColumn";
            // 
            // postCodeDataGridViewTextBoxColumn
            // 
            this.postCodeDataGridViewTextBoxColumn.DataPropertyName = "PostCode";
            this.postCodeDataGridViewTextBoxColumn.HeaderText = "PostCode";
            this.postCodeDataGridViewTextBoxColumn.Name = "postCodeDataGridViewTextBoxColumn";
            // 
            // GenerateInvoice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1109, 438);
            this.Controls.Add(this.tbl_CustomerDetailsDataGridView);
            this.Controls.Add(this.btnInvoice);
            this.Controls.Add(this.lblSubTotal);
            this.Controls.Add(this.btnAddToList);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.LstTotal);
            this.Controls.Add(this.LstQty);
            this.Controls.Add(this.lblYourOrder);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblProductPrice);
            this.Controls.Add(this.tbl_ProductDetailsDataGridView);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.txtQty);
            this.Controls.Add(this.LstProductPrice);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "GenerateInvoice";
            this.Text = "Generate Invoice O.P.S";
            this.Load += new System.EventHandler(this.GenerateInvoice_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tblCustomerRecordBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_CustomerRecords)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCustomerRecordBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblProductDetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rZGenerateInvoiceDS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_ProductDetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_ProductDetailsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rZDatabaseDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCustomerRecordBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_CustomerDetailsDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private RZCatering.ds_CustomerRecords ds_CustomerRecords;
        private System.Windows.Forms.BindingSource tblCustomerRecordBindingSource;
        private RZCatering.ds_CustomerRecordsTableAdapters.tbl_CustomerRecordTableAdapter tbl_CustomerRecordTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource tblCustomerRecordBindingSource1;
        private System.Windows.Forms.ListBox LstProductPrice;
        private RZCatering.RZGenerateInvoiceDS rZGenerateInvoiceDS;
        private System.Windows.Forms.BindingSource tblProductDetailsBindingSource;
       private RZCatering.RZGenerateInvoiceDSTableAdapters.tbl_ProductDetailsTableAdapter tbl_ProductDetailsTableAdapter;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.BindingSource tbl_ProductDetailsBindingSource;
        private RZCatering.ds_CustomerRecordsTableAdapters.tbl_ProductDetailsTableAdapter tbl_ProductDetailsTableAdapter1;
        private RZCatering.ds_CustomerRecordsTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView tbl_ProductDetailsDataGridView;
        private System.Windows.Forms.Label lblProductPrice;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label lblYourOrder;
        private System.Windows.Forms.ListBox LstQty;
        private System.Windows.Forms.ListBox LstTotal;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnAddToList;
        private System.Windows.Forms.Label lblSubTotal;
        private System.Windows.Forms.Button btnInvoice;
        private RZCatering.RZDatabaseDataSet1 rZDatabaseDataSet1;
        private System.Windows.Forms.BindingSource tblCustomerRecordBindingSource2;
       private RZCatering.RZDatabaseDataSet1TableAdapters.tbl_CustomerRecordTableAdapter tbl_CustomerRecordTableAdapter1;
        private System.Windows.Forms.DataGridView tbl_CustomerDetailsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn fnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fullAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn postCodeDataGridViewTextBoxColumn;
    }
}