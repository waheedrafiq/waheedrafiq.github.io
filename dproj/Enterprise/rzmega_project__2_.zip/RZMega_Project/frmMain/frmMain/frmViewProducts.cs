﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace frmMain
{
    
    public partial class frmViewProducts : Form
    {
       
     
        public frmViewProducts()
        {
            InitializeComponent();
        }

        private void frmViewProducts_Load(object sender, EventArgs e)
        {
         
            // TODO: This line of code loads data into the 'ds_CustomerRecords.tbl_ProductDetails' table. You can move, or remove it, as needed.
            this.tbl_ProductDetailsTableAdapter.Fill(this.ds_CustomerRecords.tbl_ProductDetails);
          
            // Format Product Price Columns to two decemal places 
            tbl_ProductDetailsDataGridView.Columns[3].DefaultCellStyle.Format = "N";
          

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnReturnP_Click(object sender, EventArgs e)
        {
            frmProductDetails disProduct = new frmProductDetails();
            disProduct.Show();
            this.Hide();
        }

        

        
    }
}
