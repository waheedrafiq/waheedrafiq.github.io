﻿namespace frmMain
{
    partial class frmViewProducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmViewProducts));
            this.tblProductDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            //this.ds_CustomerRecords = new frmMain.ds_CustomerRecords();
            this.dsCustomerRecordsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            //this.tbl_ProductDetailsTableAdapter = new frmMain.ds_CustomerRecordsTableAdapters.tbl_ProductDetailsTableAdapter();
            //this.tableAdapterManager = new frmMain.ds_CustomerRecordsTableAdapters.TableAdapterManager();
            this.tbl_ProductDetailsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnReturnP = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tblProductDetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_CustomerRecords)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsCustomerRecordsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_ProductDetailsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // tblProductDetailsBindingSource
            // 
            this.tblProductDetailsBindingSource.DataMember = "tbl_ProductDetails";
            this.tblProductDetailsBindingSource.DataSource = this.ds_CustomerRecords;
            // 
            // ds_CustomerRecords
            // 
            this.ds_CustomerRecords.DataSetName = "ds_CustomerRecords";
            this.ds_CustomerRecords.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dsCustomerRecordsBindingSource
            // 
            this.dsCustomerRecordsBindingSource.DataSource = this.ds_CustomerRecords;
            this.dsCustomerRecordsBindingSource.Position = 0;
            // 
            // tbl_ProductDetailsTableAdapter
            // 
            this.tbl_ProductDetailsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tbl_CustomerRecordTableAdapter = null;
            this.tableAdapterManager.tbl_ProductDetailsTableAdapter = this.tbl_ProductDetailsTableAdapter;
           // this.tableAdapterManager.UpdateOrder = frmMain.ds_CustomerRecordsTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tbl_ProductDetailsDataGridView
            // 
            this.tbl_ProductDetailsDataGridView.AllowUserToAddRows = false;
            this.tbl_ProductDetailsDataGridView.AllowUserToDeleteRows = false;
            this.tbl_ProductDetailsDataGridView.AutoGenerateColumns = false;
            this.tbl_ProductDetailsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.tbl_ProductDetailsDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedHeaders;
            this.tbl_ProductDetailsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tbl_ProductDetailsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.tbl_ProductDetailsDataGridView.DataSource = this.tblProductDetailsBindingSource;
            this.tbl_ProductDetailsDataGridView.Location = new System.Drawing.Point(31, 25);
            this.tbl_ProductDetailsDataGridView.Name = "tbl_ProductDetailsDataGridView";
            this.tbl_ProductDetailsDataGridView.ReadOnly = true;
            this.tbl_ProductDetailsDataGridView.RowTemplate.Height = 24;
            this.tbl_ProductDetailsDataGridView.Size = new System.Drawing.Size(566, 266);
            this.tbl_ProductDetailsDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ProductID";
            this.dataGridViewTextBoxColumn1.HeaderText = "ProductID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 99;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Product_Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Product_Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 131;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Product_Description";
            this.dataGridViewTextBoxColumn3.HeaderText = "Product_Description";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 165;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Product_Price";
            this.dataGridViewTextBoxColumn4.HeaderText = "Product_Price";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 126;
            // 
            // btnReturnP
            // 
            this.btnReturnP.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturnP.Location = new System.Drawing.Point(464, 297);
            this.btnReturnP.Name = "btnReturnP";
            this.btnReturnP.Size = new System.Drawing.Size(133, 54);
            this.btnReturnP.TabIndex = 1;
            this.btnReturnP.Text = "Return to Product Details";
            this.btnReturnP.UseVisualStyleBackColor = true;
            this.btnReturnP.Click += new System.EventHandler(this.btnReturnP_Click);
            // 
            // frmViewProducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(611, 356);
            this.Controls.Add(this.btnReturnP);
            this.Controls.Add(this.tbl_ProductDetailsDataGridView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmViewProducts";
            this.Text = "View Products Details";
            this.Load += new System.EventHandler(this.frmViewProducts_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tblProductDetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_CustomerRecords)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsCustomerRecordsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_ProductDetailsDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.BindingSource dsCustomerRecordsBindingSource;
       private RZCatering.ds_CustomerRecords ds_CustomerRecords;
        private System.Windows.Forms.BindingSource tblProductDetailsBindingSource;
      private RZCatering.ds_CustomerRecordsTableAdapters.tbl_ProductDetailsTableAdapter tbl_ProductDetailsTableAdapter;
      private RZCatering.ds_CustomerRecordsTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView tbl_ProductDetailsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Button btnReturnP;
    }
}