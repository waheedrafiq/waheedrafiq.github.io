﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.IO;


namespace frmMain
{
    public partial class GenerateInvoice : Form
    {
        public decimal dSubTotal;
        public decimal dec;
        public int ProductQty;
        //private string Lst;
        public GenerateInvoice()
        {
            InitializeComponent();
        }

        void fill_listbox()
        {


        }
        private void GenerateInvoice_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'rZDatabaseDataSet1.tbl_CustomerRecord' table. You can move, or remove it, as needed.
            //this.tbl_CustomerRecordTableAdapter1.Fill(this.rZDatabaseDataSet1.tbl_CustomerRecord);
            // TODO: This line of code loads data into the 'ds_CustomerRecords.tbl_ProductDetails' table. You can move, or remove it, as needed.
            this.tbl_ProductDetailsTableAdapter1.Fill(this.ds_CustomerRecords.tbl_ProductDetails);

            // TODO: This line of code loads data into the 'ds_CustomerRecords.tbl_CustomerRecord' table. You can move, or remove it, as needed.
            this.tbl_CustomerRecordTableAdapter.Fill(this.ds_CustomerRecords.tbl_CustomerRecord);

            // Format Product Price Columns to two decemal places 
            tbl_ProductDetailsDataGridView.Columns[2].DefaultCellStyle.Format = "N";

            string select = "SELECT * FROM tbl_ProductDetails ORDER BY Product_Name";
           // SqlConnection conn = new SqlConnection(Properties.Settings.Default.RZDatabaseConnectionString);
          
            
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|/RZDatabase.mdf;Integrated Security=True");
            // SqlConnection conn = new SqlConnection(Properties)
            SqlDataAdapter dataAdapter = new SqlDataAdapter(select, conn);
            SqlCommandBuilder cb = new SqlCommandBuilder(dataAdapter);

            DataSet ds = new DataSet();

       
            dataAdapter.Fill(ds);
            tbl_ProductDetailsDataGridView.ReadOnly = true;
            tbl_ProductDetailsDataGridView.DataSource = ds.Tables[0];

            
            DisableGridviewSorting(tbl_ProductDetailsDataGridView);
            btnInvoice.Enabled = false;

            this.tbl_ProductDetailsDataGridView.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
           // this.tbl_ProductDetailsDataGridView.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.tbl_ProductDetailsDataGridView.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            this.tbl_ProductDetailsDataGridView.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;




        }
        public void DisableGridviewSorting(DataGridView grid)
        {
            for (int i = 0; i < grid.Columns.Count; i++)
            {
                grid.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Return to Main button 
            FrmMain disMain = new FrmMain();
            disMain.Show();
            this.Hide();


        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //txtUnitPrice.Text = listBox1.DisplayMember;

            //txtUnitPrice.Text = LstProductPrice.SelectedItems.ToString();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        //private void txtAddToInvoice_Click(object sender, EventArgs e)
        //{
        //    // Select the value from table that user has selected product 
        //    DataGridViewRow dr = tbl_ProductDetailsDataGridView.SelectedRows[0];

        //    string UnitPriceS; // String value 
        //    int Quantity;
        //    decimal total;
        //    decimal subTotal;
        //    decimal[] SubtotalList;

        //    btnGenerateInvoice.Enabled = true;


        //    // storing the value that user has click  to UnitPrices
        //    UnitPriceS = dr.Cells[3].Value.ToString();

        //    decimal UnitPrice = Math.Round(Convert.ToDecimal(UnitPriceS), 2);

        //    Quantity = Convert.ToInt32(txtQty.Text);


        //    total = UnitPrice * Quantity;

        //    MessageBox.Show(total.ToString());






        //}

        // add a local class 
        static void SubTotalLS(ArrayList SubtotalList)
        {
            foreach (int i in SubtotalList)
            {
                // add something here 


            }


        }

        private void tbl_ProductDetailsDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

           

        }

        private void tbl_ProductDetailsDataGridView_MouseClick(object sender, MouseEventArgs e)
        {


        }



        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tbl_ProductDetailsTableAdapter1.FillBy(this.ds_CustomerRecords.tbl_ProductDetails);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnAddToList_Click(object sender, EventArgs e)
        {
            // store values from DataGridViewRow to variables
            string UnitPriceS; // String value 
            decimal total;
            // Select the value from table that user has selected product 
            DataGridViewRow dr = tbl_ProductDetailsDataGridView.SelectedRows[0];
            btnInvoice.Enabled = true;

            // storing the value that user has click  to UnitPrices
            UnitPriceS = dr.Cells[2].Value.ToString();
            listBox1.Items.Add(dr.Cells[0].Value.ToString());
            LstProductPrice.Items.Add(string.Format("{0:0.00}", dr.Cells[2].Value));
            // Convert hte UnitPriceS string value to decimal variable UnitPrice
            decimal ProductPrice = Math.Round(Convert.ToDecimal(UnitPriceS), 2);


            if (String.IsNullOrEmpty(txtQty.Text.ToString()))
            {
                // MessageBox.Show("Please enter 0 in Qty box");
                txtQty.Text = "1";

            }

            ProductQty = Convert.ToInt32(txtQty.Text);
            LstQty.Items.Add(ProductQty);
            //ProductSubTotal
            total = ProductPrice * ProductQty;

            //ListBox
            LstTotal.Items.Add(total.ToString());


            var listarray = new System.Collections.ArrayList(LstTotal.SelectedItems);


            for (int i = 0; i < LstTotal.Items.Count; i++)
            {
                //dSubTotal = Convert.ToDecimal(LstTotal.Items[i].ToString()); //+ Convert.ToDecimal(LstTotal.Items[i].ToString());

                dec = Convert.ToDecimal(LstTotal.Items[i].ToString());

            }
            dSubTotal += dec;
            lblSubTotal.Text = "SUB TOTAL £" + dSubTotal.ToString();



        }

        private void btnInvoice_Click(object sender, EventArgs e)
        {
            string UnitPriceS;
            string Fullname, Address, Postcode;
            DataGridViewRow dr = tbl_ProductDetailsDataGridView.SelectedRows[0];
            UnitPriceS = dr.Cells[2].Value.ToString();
            decimal ProductPrice = Math.Round(Convert.ToDecimal(UnitPriceS), 2);

            // Customer details are pull from the database 
            DataGridViewRow drCus = tbl_CustomerDetailsDataGridView.SelectedRows[0];

            Fullname = drCus.Cells[0].Value.ToString();
            Address = drCus.Cells[1].Value.ToString();
            Postcode = drCus.Cells[2].Value.ToString();





            string FileName = DateTime.Now.ToString("yyyyMMddHHmmss") + "-Invoice.txt";
            TextWriter tw = File.CreateText(@"C:\RZStore\" + FileName);
            tw.Close();
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\RZStore\" + FileName))
            {
                file.WriteLine("================================================================================================================");
                file.WriteLine("Invoice: " + Fullname.ToString().Trim() +"\t"+ Address.ToString().Trim() +"\t"+ Postcode.ToString().Trim());
                file.WriteLine("================================================================================================================");
                file.WriteLine("Date Created: " + DateTime.Now.ToString());//DateTime.Now.ToShortDateString() +
                file.WriteLine("-----------------------------------------------------------------------------------------------------------------");
                file.WriteLine("ProductName\t\t| Price\t\t| Qty\t\t| Total         ");
                file.WriteLine("-----------------------------------------------------------------------------------------------------------------");



                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    file.WriteLine(listBox1.Items[i].ToString().Trim() + "\t\t| " + LstProductPrice.Items[i].ToString() + "\t| " + LstQty.Items[i].ToString() + "\t\t| " + LstTotal.Items[i].ToString());

                }



                file.WriteLine("-----------------------------------------------------------------------------------------------------------------");
                file.WriteLine("Sub Total: £" + dSubTotal.ToString());
                file.WriteLine("-----------------");
                file.Flush();
                 
               

            }
            MessageBox.Show("Invoice generated" + "\n" + " in C drive RZStore folder");
            btnInvoice.Enabled = false;
        }

        private void tbl_CustomerDetailsDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

    

