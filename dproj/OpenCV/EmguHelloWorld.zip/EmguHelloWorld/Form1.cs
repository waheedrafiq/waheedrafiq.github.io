﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO; 
// Reference for Emgu 
using Emgu.CV;

using Emgu.Util;

using Emgu.CV.Structure;


namespace EmguHelloWorld
{
    public partial class FrmCameraCapture : Form
    {
        public FrmCameraCapture()
        {
            InitializeComponent();
        }
        // declare global variables
        private Capture capture;  // taking images from camrea as image frames
        private bool captureInProgress;  // check if capture is executing

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        // to experiment later on with 
        //Image<Bgr, Byte> frame = capture.QueryFrame();

        //Image<Gray, Byte> grayFrame = frame.Convert<Gray, Byte>();
        //Image<Gray, Byte> smallGrayFrame = grayFrame.PyrDown();
        //Image<Gray, Byte> smoothedGrayFrame = smallGrayFrame.PyrUp();
        //Image<Gray, Byte> cannyFrame = smoothedGrayFrame.Canny(new Gray(100), new Gray(60));

        // imageBox1.Image = frame;



        private void ProcessFrame(object sender,EventArgs arg)
        {
            Image<Bgr, byte> ImageFrame = capture.QueryFrame();
            imageBox1.Image = ImageFrame;


        }
        private void btnStart_Click(object sender, EventArgs e)
        {

            
            if (capture == null)
            {
                try
                {
                    capture = new Capture();

                }
                catch (NullReferenceException excpt)
                {
                    MessageBox.Show(excpt.Message);

                }
            }//end of capture 

            if (capture != null)
            {
                if (captureInProgress)
                {
                    // if camera is getting the frames
                    btnStart.Text = "Camera activated";
                    Application.Idle -= ProcessFrame;


                }
            }
            else
            {
                // if camera is not getting frames then start the capture  set button
                btnStart.Text = "Stop Camera";
                Application.Idle += ProcessFrame;
            }

            captureInProgress = !captureInProgress; 



        }

        private void ReleaseData()
        {
            if (capture != null)
                capture.Dispose(); 
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Image<Bgr, byte> ImageFrame = capture.QueryFrame();
            ImageFrame.Save(@"C:\blindximages\EmguPic.jpg");
        }

       
    }
}
