﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace codeProjectExample
{
    class Program : men
    {
        static void Main(string[] args)
        {
            Penguin obj = new Penguin();
            

            obj.feathers = "Yes";
            obj.wings = "Yes ";
            obj.MaxEggs = 2; //calling property of base class Bird
            obj.size = 200;
            obj.fly = "No";
            obj.swim = "yes";
            obj.diet = "fish";
            obj.methodpenguin();

            men Questions = new men();

            Console.WriteLine("Do you enjoy sex==>");
            Questions.sex = Console.ReadLine();
            Console.WriteLine("What is your Name? ");
            Questions.Name = Console.ReadLine();
            Console.WriteLine("What is your favorite sex postion you enjoy doing");
            Questions.SexPostion = Console.ReadLine();
            Console.WriteLine("How many time you enjoying doing it?");
          
            Questions.HowManytimes = Convert.ToInt32(Console.ReadLine());

            Questions.answers();






            Console.ReadKey();

        }
    }

    public class Bird // Base class
    {
        public string feathers;
        public string wings;
        public int maxEggs;
        public int size; 
        
        public void attribute()
        {
            Console.WriteLine("feathers:" + feathers);
            Console.WriteLine("wings:" + wings);

            Console.WriteLine("maxEggs:" + maxEggs);

            Console.WriteLine("size:" + size);

        }// end of attribute class

        public int MaxEggs
        {
            get
            {
                return maxEggs;
            }
            set
            {
                if (value >= 1 && value <= 2) 
                {
                    maxEggs = value; 
                }
                else
                {
                    maxEggs = 1; 
                }
            }
        }

    } // end of Bird class 


    public class Penguin : Bird //derived class can access all members of base class
    {
        public string fly;

        public string swim;

        public string diet;

        public void methodpenguin()
        {
            //subclass 'penguin' refers to the members of super class 'Bird'

            Console.WriteLine("feathers: " + feathers);

            Console.WriteLine("wings: " + wings);

            Console.WriteLine("maxEggs: " + maxEggs);

            Console.WriteLine("size: " + size);

            Console.WriteLine("fly: " + fly);

            Console.WriteLine("swim: " + swim);

            Console.WriteLine("diet: " + diet);
            Console.ReadKey(); 
        }
    }










}
