﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace codeProjectExample
{
    public class men
    {
        // declare ma instance variables 
        public string sex = "sex";
        public string SexPostion;
        public string Name; 
        public int HowManytimes;   // note never declare them public , this is only for this exercise.

        public void  answers()
        {
            Console.WriteLine(Name + "enjoys "+ sex);
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("your best sex postion is:" + SexPostion);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("you enjoy doing it:" + HowManytimes +" times ");
            Console.ReadKey();
        }
    }
}
