﻿// Engine 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YourExampleofInheritance
{
    class engine : VehicleModel
    {
        private int engineVCCNumber, HorsePower;
  

        // first constructor 
        public engine(int a , int b )
            : base(a, b)
        {
            this.engineVCCNumber = a;
            this.HorsePower = b;
        }

        // second constructor 

        public engine(string s)
            : base(s)
        {}

       

        public Tuple<int,int> engineInfo(int a, int b)
        {

            base.DrawLine();// Drawline for user interface inheritance from VehicleModel
            Console.Write("\n");
            Console.Write("What is your Engine VCC Number ==>");
            a = int.Parse(Console.ReadLine());
            Console.Write("\n");
            Console.Write("What is your vehicle hourse Power ===>");
            b = int.Parse(Console.ReadLine());

            base.blankLine();
            base.DrawLine();
         
            return Tuple.Create(a, b);

        }


       

    }
}
