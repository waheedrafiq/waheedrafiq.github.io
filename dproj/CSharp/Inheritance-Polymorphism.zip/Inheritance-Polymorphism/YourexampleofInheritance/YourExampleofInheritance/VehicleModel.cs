﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YourExampleofInheritance
{
    class VehicleModel
    {
        protected string Model;
        private int engineVCCNumber, HorsePower;

        public VehicleModel(int a ,int b)
        {
            this.engineVCCNumber = a;
            this.HorsePower = b; 
        }

        public int GetTotal()
        {
            return engineVCCNumber * HorsePower;
        }
        public VehicleModel(string s)
        {
            this.Model = s;

        }

        public string GetInformation( string s)
        {

            DrawLine();
            Console.Write("\t\t" + "Vehicle Information  Request");
            blankLine();
            Console.Write("\nWhich model is the vehicle? ==>");
            Model = Console.ReadLine();
            return Model; 
        }
        public void DrawLine()
        {
            for (int i = 0; i < Console.WindowWidth; i++)
            {
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.Write("=");
            }
            Console.WriteLine("\n"); // insert blank line.
        }// end of DrawLine

        public void blankLine()
        {
            Console.WriteLine("\n");
        }
    }
}
