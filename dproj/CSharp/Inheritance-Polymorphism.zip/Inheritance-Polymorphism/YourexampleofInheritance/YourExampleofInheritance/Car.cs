﻿// example of inheritance 
// to ensure you understand what Inheritance is.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YourExampleofInheritance
{
    class Car 

    {
        static void Main(string[] args)
        {
         engine t = new engine("");

     
        


         Console.WriteLine("The information return is  {0}:", t.engineInfo(12, 2));
         Console.Write("Vehicle model is :{0} ", t.GetInformation(""));

            

            Console.ReadKey();


        }
    }
}
