﻿using System;
namespace RectangleApplication
{
   
   
   class ExecuteRectangle
   {
      static void Main(string[] args)
      {
         
          
         Tabletop t = new Tabletop(10.5, 7.5);
         t.Display();
         Console.ReadLine();
      }
   }
}
