﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsolePolymorphism
{ // ListBox derives from Control
    class ListBox : Control
    {
        private string listBoxContents;  // new member variable 

        public ListBox(int t, int l, string contents) : base(t,l)
        }
         listBoxContents = contents; 
        }

    }
}
