﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsolePolymorphism
{
    class Polymorphism
    {
        static void Main(string[] args)
        {


        }
    }
}
