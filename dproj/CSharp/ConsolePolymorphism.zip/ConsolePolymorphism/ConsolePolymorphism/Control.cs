﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsolePolymorphism
{
    class Control
    {// There data members are protected, rather than private
        // and therefore visible to derived class method

        protected int top;
        protected int left; 

        // constructor locates postion of control
        public Control(int t, int l )
        {
            this.top = t;
            this.left = l; 
        }


        // delcare DrawControl() to be virtual therefore
        // allowing it to be overridden in a derived class
        public virtual void DrawControl()
        {
            Console.WriteLine("Control : drawing Control at {0} , {1}", top, left);
        }




    }// end of control class 
}
