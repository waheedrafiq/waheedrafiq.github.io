Don't forget to include your test data Excell Important ! 
will lose marks



//  Author: Waheed Rafiq
//  Date:   29/10/2015
//  File:   LitresGallonsApplications.cs
//
//  class definition :
// Application Print a conversion chart , that will display the 
// equivalent values for litres and gallows.
// www.waheedrafiq.net 
//Student ID: S13189954
