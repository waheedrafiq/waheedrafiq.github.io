﻿//  Author: Waheed Rafiq
//  Date:   29/10/2015
//  File:   LitresGallonsApplications.cs
//
// class definition :GeneralConversion.cs
// Application Print a conversion chart , that will display the 
// equivalent values for litres and gallons.
// www.waheedrafiq.net 
//Student ID: S13189954
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneralConversion
{
    class GeneralConversion
    {
        
        static void Main(string[] args) 
        {
            Conversion Menu = new Conversion(""); // Declare new object Menu 
            int choice = 0;

            do
            {// Display Menu Interface from Conversion Class and save the choice to integer choice datatype
                choice = Menu.MenuInterface(choice); 
                // if choice equal to selected choice from Menu.Interface run method.
                if (choice == 1)
                {
                    Menu.LG(); // run LG method from Conversion class
                }
                else if (choice == 2) 
                {
                    Menu.StandardConversion(); // run StandardConversion method
                }
                else if (choice == 3)
                {
                    Console.WriteLine("Press Any Key to exit !");
                    Console.ReadKey(); // wait for the user to select any key input.
                }
            } while (choice != 3);// end of while loop   
        } // end of Main Class
    }// End of LitresGallonsApplication
}// End of namespace LitresGallonsApplication 
