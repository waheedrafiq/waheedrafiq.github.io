﻿//  Author: Waheed Rafiq
//  Date:   29/10/2015
//  File:   Conversion.cs
//
// class definition :GeneralConversion.cs
// Application Print a conversion chart , that will display the 
// equivalent values for litres and gallons.
// www.waheedrafiq.net 
//Student ID: S13189954
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading; 


namespace GeneralConversion
{
    class Conversion
    {
        // declare variables to be used
        private string sDisplay , sFromUnit , sToUnit; // variable to be used within conversion class
        private double   interspersed,LitresFactor = 0.220,  GallonsFactor = 4.54609; // variables to be used for Litres / Gallons / StandardConversion
        private double  StandardFactorValue1, standardFactorValue2,totalDB2, totalDB=1   ; // To be used within StandardConversion method.
        private int MenuChoice, ListLen; // To be used for Menu choice and conversion chart list length
        private int q = 0; // to be used within Conversion ConversionCalculator()
        private bool exit; // to be used within conversionCalculator()
        private double amountStartPoint = 1; // amount starting point will start from 1
        

        // first constructor 
        public Conversion( string s)
        {
            // Intialise current instance of sDisplay 
            this.sDisplay = s; 
        }
        // second constructor 2 selection for menu
        public  Conversion(double L, double G )
        {
            // Intialise current instance of Litres and Gallons
            this.LitresFactor = L; 
            this.GallonsFactor =G; 
        }

        // third constructor intialise Menu choice 
        public Conversion(int ch)
        {
            // Intialise current instance of MenuChoice
            this.MenuChoice = ch; 
        }

        //====================================
        //      METHOD MENU INTERFACE
        //====================================
        // Basic interface Litres and Gallons
        public int MenuInterface( int s)
        {
            Console.Clear(); //  clear previous text
            MenuChoice = 0; // Intialise Menu Choice.
            Console.ForegroundColor = ConsoleColor.Blue; // change the Fore Ground color to Blue 
            sDisplay = "\nStudent ID & Name: S13189954 , Waheed Rafiq";
            sDisplay += "\nAll Copyright Reserved (c)";
            sDisplay += "\nApplication: Print a conversion chart , that will display the ";
            sDisplay += "\nequivalent values for litres and gallons.";
            sDisplay += "\nStandard Conversion allows user to enter their own values for the conversion.";
            sDisplay += "\n";
            sDisplay += "\n\t*****************************************";
            sDisplay += "\n\t**        General Conversion Charts    ** ";
            sDisplay += "\n\t*****************************************";
            sDisplay += "\n";
            sDisplay += "\n";
            sDisplay += "\n\tPlease make a selection from the Menu ";
            sDisplay += "\n";
            sDisplay += "\n\t [1] Convert Litres to Gallons";
            sDisplay += "\n\t [2] Standard Conversion" ;
            sDisplay += "\n\t [3] Quit Application  ";
            Console.Write(sDisplay);
            Console.ForegroundColor = ConsoleColor.Gray; // change fore ground color to gray 
            Console.WriteLine(""); // blank line 

            // Error trapping code if user enter a character message is display 
            // keep looping until the correct choice is selected.
            MenuChoice = GetInt("\nPlease Enter your choice:==> ");

            return MenuChoice; // return int MenuChoice 
        }// end of MenuInterface method. 
        //====================================
        //      METHOD LITRES AND GALLONS
        //====================================
        
        // Method for Converting Literes to Gallons
        public void  LG()
        {
            int n = 0;
            amountStartPoint = 1; // Reset start point again. 
            exit = false; // reset exit to false
            Console.Clear(); // clear any text on console screen
            Console.ForegroundColor = ConsoleColor.Cyan; // change fore ground colour to cyan
          
            sDisplay = "\n" + "\t*****************************************";
            sDisplay += "\n" +"\t** Conversion Chart Litres and Gallons  ** ";
            sDisplay += "\n" +"\t******************************************";
            sDisplay += "\n";
            sDisplay += "\n";
            Console.Write(sDisplay); // display user interface for Liters and Gallons
            Console.ForegroundColor = ConsoleColor.Gray; // change fore ground colour to Gray
            // Error trapping code if user enters a character, a message is displayed 
            // keep looping until the integer  is entered.
            ListLen = GetInt("\nPlease enter the list lenght ==> ");
            // Console write Litres and add double tabs then add to the string Gallons.
            Console.Write("\nLitres" + "\t\t" +"Gallons");
            Console.Write("\n"); //Insert blank line 
            // Loop until the value of 'amountStartPoint' is less or equal to ListLen
            // and loop until exit is not true.
            // For next loop is not used as I would have had to use a while loop and for loop to acheive my objective.
            // As coder I chose a while loop which acheives my objective.
            while( amountStartPoint <=  ListLen && exit !=true)
            {
                // Calculate : amountStartPoint divide by GallonsFactor = 4.54609
                // amountStartPoint in this case is Litres default to 1 and later on incermented by 1
                //One way of Conversion is: 1 / 4.54609
                // Which will result to 1 litres divide by 4.54609 equals to 0.220 so you use GallonsFactor
                // instead of Litres.

                totalDB = amountStartPoint / GallonsFactor; 
                // value for litres is displayed
                // ToString is used to display the correct decimal format
                Console.Write("\n {0}", amountStartPoint.ToString("#.000")); 
                Console.Write("\t\t{0}", totalDB.ToString("0.000")); // value for totalDB is displayed 
                // As the value for GallonsFactor and LitresFactor in this section 
                // will never change. 
                // Litre equivalent of each half gallon interspersed in table.
                // Check if the amountStartPoint is at every second is true then perform interspersed. 
                if (amountStartPoint % 2 == 0)
                {
                    // This section of code  Calculate the value of 0.5 example.
                    // amountStartPoint is 2 divide by 4 = 0.5 multiply by 4.54609 
                    // store this value in Interspersed datatype.
                    interspersed = (amountStartPoint / 4) * GallonsFactor;
                    // Second stage of this calculation is: interspersed value which is 2.273 Multiply
                    // by LitresFactor which is 0.220  store the value in totalDB which is 0.500.
                    // This style of maths meet the first object of the Conversion chart assignment.
                    totalDB = interspersed * LitresFactor;
                    // From the above values console write in the correct format
                    Console.Write("\n {0}", interspersed.ToString("#.000"));
                    Console.Write("\t\t{0}", totalDB.ToString("0.000"));
                }
                if (amountStartPoint % 7 == 0) // check for every 7th line 
                {
                    exit = Paused(exit); // return bool 
                    if(exit==true)
                    {
                        // Reset value
                        amountStartPoint = 1;
                        MenuInterface(n); // call upon the MenuInterface pass empty value.
                    }
                }// End of if check 7th Line.
               amountStartPoint++; // Increment amountStartPoint 
            } // While Loop 
            Console.ReadKey();
            
        }// End of Public LG method

        //====================================
        //      METHOD STANDARD CONVERSION
        //====================================
       // Method for standard conversion
        public void StandardConversion( )
        {
            exit = false; // reset exit to false
            ListLen = 0; // reset ListLen

            Console.Clear(); // clear any text on console screen
            Console.ForegroundColor = ConsoleColor.Cyan; // change fore ground colour to cyan
            sDisplay = "\n" + "\t*****************************************";
            sDisplay += "\n" + "\t** Standard Conversion                 ** ";
            sDisplay += "\n" + "\t*****************************************";
            sDisplay += "\n";
            sDisplay += "\n";
            Console.Write(sDisplay); // display user interface for Standard Conversion
            Console.ForegroundColor = ConsoleColor.Gray; // change fore ground colour to Gray
            
            Console.Write("\nPlease enter the name of the unit from: ==>");
            sFromUnit = Console.ReadLine();
            Console.Write("\nPlease enter the name of the  unit to:==>");
            sToUnit = Console.ReadLine();
            // Error trapping code if user enters a character, a message is displayed 
            // keep looping until the correct value is selected, use GetDouble() Method to check.
            Console.Write("\nPlease enter your conversion constant for {0}",sFromUnit); // display string FromUnit
            StandardFactorValue1 = GetDouble(":==>");
            // Error trapping code if user enters a character, a message is displayed 
            // keep looping until the correct value is selected, use GetDouble() Method to check.
            Console.Write("\nPlease enter your conversion constant for {0}", sToUnit); // Display string ToUnit. 
            standardFactorValue2 = GetDouble(":==>");
            // Error trapping code if user enters a character, a message is displayed 
            // keep looping until the integer choice is entered
            ListLen = GetInt("\nPlease enter the conversion chart list length:==>");
            Console.ForegroundColor = ConsoleColor.DarkYellow; // change the foreground colour to dark yellow
            Console.Write("\n" + sFromUnit + "\t\t" + sToUnit);
            Console.Write("\n"); // insert blank line 
            Console.ForegroundColor = ConsoleColor.Gray; // change the foreground colour to Gray
            // call ConCal to workout values entered by user. 
            ConversionCalculator(totalDB);
            Console.ReadKey();
        }// End of standard conversion. 
       
           //====================================
           //      METHOD Get double 
           //====================================
           // GetDouble() ensure user enters a double value keep prompting until double is entered
           private static double GetDouble(string prompt)
           {
               double tempDBL;
               string tempStr;
               do
               {
                   Console.Write(prompt + " ");
                   // read value from user store in tempStr variable
                   tempStr = Console.ReadLine();
                   // if its not double value prompt user Invalid value 
                   if (!double.TryParse(tempStr, out tempDBL))
                   {
                       Console.Write("\nInvalid value character !");
                   }
                   // while it is not double value keep looping until it is true.
               } while (!double.TryParse(tempStr, out tempDBL));
               return tempDBL; // return tempDBL
           } // end of GetDouble() Method

           //====================================
           //      METHOD Get whole number
           //====================================
           // GetInt() ensure user enters a whole value, keep prompting until Integer is entered
           private static int GetInt(string prompt)
           {
               int tempINT;
               string tempStr;
               do
               {
                   Console.Write(prompt + " ");
                   tempStr = Console.ReadLine();
                   // if it is not integer display in console string
                   if (!int.TryParse(tempStr, out tempINT))
                   {
                       Console.Write("\nInvalid  character value !");
                   }
                   // While it is not integer keep looping 
                
               } while (!int.TryParse(tempStr, out tempINT));
               return tempINT;
           } // end of GetInt() Method 

           //====================================
           //      METHOD Conversion Calculator
           //====================================
        public double ConversionCalculator(double x)
        {
            int n = 0;
            exit = false; // Initalise exit to false
            amountStartPoint = 1; 
            // The reason for not using a for loop with a while is , why have two loops 
            // when you can get away with one loop that will result in the same logic.
            // while amountStartPoint is less or equal to ListLen loop and exit is not true.
            // Both condition have to be true for the loop to perform the logic within.
            
            while (amountStartPoint <= ListLen && exit != true)
            {
                //This section of the code demonstrate that by applying a different
                // style of math algorithm you can adapt a standard approach to Conversion.
                // Using the example from LG() method instead of dividing by GallonFactor
                // we multiply by literFactor as this section is for General conversion
                // the user can input anything they want to convert 
                // To explain in simple way we shall stick to Litres = 0.220 and Gallons to 4.54609

                // amountStartPoint is 1 multiply by Litres rate(StandardFactorValue1) 0.220
                // store the value in totalDB which is 0.220.
                totalDB = amountStartPoint * StandardFactorValue1;
                // amountStartPoint which at this stage of the code is 1 add 1 to it.
                // Calcaluate amountStartPoint first  value is at 2 then multiply by StandardFactorValue1 
                // store value in totalDB2
                totalDB2 = (amountStartPoint + 1) * StandardFactorValue1;

                // value for litres is displayed
                // ToString is used to display the correct decimal format
                Console.Write("\n {0}", amountStartPoint.ToString("#.000"));
                Console.Write("\t\t{0}", totalDB.ToString("0.000")); // value for totalDB is displayed 
                // At this stage of the code TotalDB is 0.220 which is less than totalDB2 which is 0.440
                // and exit is not true.
                while (totalDB < totalDB2 && exit != true) 
                {  //check if between totalDB and totalDB2 we can find any 0.5 
                    // totalDB is at 0.220
                    // if totalDB can be diveded exactly by 0.5
                    // example 50/100=50% = 0.5 
                    if (totalDB % 0.5 == 0) 
                    {
                        totalDB = totalDB + 0.5; // then add 0.5 to totalDB
                    }
                    else if (totalDB % 0.5 != 0) // else if it can not, do this:
                    {
                        q = Convert.ToInt32(totalDB);// round the totalDB and store it in q
                        // if it was rounded to a lower number than the original add 0.5
                        if (q < totalDB) totalDB = q + 0.5;
                        else totalDB = q;  // if it was rounded to a bigger number than the original, store the same value.
                    }
                    // calcaulate value for interspersed 
                    // totalDB is at 0.5 multiply by Gallon value 4.54609
                    // at each loop totalDB will change so it won't be always at 0.5
                    // store it in Interspresed datatype.
                    interspersed = totalDB * standardFactorValue2;
                    if (totalDB < totalDB2) // if totalDB is less than totalDB2 
                    {
                        Console.Write("\n {0}", interspersed.ToString("#.000"));
                        Console.Write("\t\t{0}", totalDB.ToString("0.000"));
                    }
                    if (amountStartPoint % 7 == 0) // check for every 7th line 
                    {
                        exit = Paused(exit); // return bool 
                        if (exit == true)
                        {
                            // Reset value
                            amountStartPoint = 1;
                            MenuInterface(n); // call upon the MenuInterface pass empty value.
                        }
                    }
                }// end of check totalDB loop.
                amountStartPoint++; // incerment amountStartPoint 
               
            }// end of while statement and exit check 
                    
          
            return totalDB; // return totalDB
        }// end of ConversionCalculator() method 

       //==============================
       //      METHOD PAUSED
       //==============================
        public static bool Paused(bool t)
        {
            string tempStr; //  temporary variable string to be use for user input.
           

            Console.WriteLine("\nPress any key to continue... or [N] for Exit Program");
            tempStr = Console.ReadLine().ToUpper();

            if(tempStr=="N") // if the value is N then execute condition 
            {
                t = true; // t is true
                Console.WriteLine("\nExiting Program....");
                Console.Beep();
              
            }
            Thread.Sleep(1000); // delay for 1 second.
            return t; // return bool value for t default false.
        }// end of pause class 
         
    }// end of class Conversion
}// end of namespace LitresGallonsApplicaiton 
