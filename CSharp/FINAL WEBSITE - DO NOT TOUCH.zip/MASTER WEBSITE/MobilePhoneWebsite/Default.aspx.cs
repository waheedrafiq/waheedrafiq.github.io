﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected MobilePhoneBLL mobilePhoneBLL = new MobilePhoneBLL();

    protected void Page_Load(object sender, EventArgs e)
    {
        LoadData();
    }

    // Load data
    protected void LoadData() 
    {
        dlMobilePhone.DataSource = mobilePhoneBLL.ViewAllPhoneOnHome();
        dlMobilePhone.DataBind();

    }

    protected void dlMobilePhone_ItemCommand(object sender, DataListCommandEventArgs e)
    {
        try
        {
            //frmMobilePhone.Visible = false;
            
            int id = Convert.ToInt16(dlMobilePhone.DataKeys[e.Item.ItemIndex]);
            if (e.CommandName.Equals("ViewDeal"))
            {
                dlMobilePhone.Visible = false;
                frmMobileInfo.Visible = true;
                frmMobileInfo.DataSource = mobilePhoneBLL.View(id);
                frmMobileInfo.DataBind();
            }

        }
        catch (Exception)
        {


        }

    }
}