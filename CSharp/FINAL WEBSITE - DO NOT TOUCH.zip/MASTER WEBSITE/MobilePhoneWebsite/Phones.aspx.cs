﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Phones : System.Web.UI.Page
{
    // Declare variable mobilePhoneBLL
    protected MobilePhoneBLL mobilePhoneBLL = new MobilePhoneBLL();

    protected void Page_Load(object sender, EventArgs e)
    {
        LoadData();
    }

    protected void LoadData()
    {
        dlMobilePhone.DataSource = mobilePhoneBLL.ViewAllPhones();
        dlMobilePhone.DataBind();

    }

    protected void dlMobilePhone_ItemCommand(object sender, DataListCommandEventArgs e)
    {
        try
        {
            //frmMobilePhone.Visible = false;
            int id = Convert.ToInt16(dlMobilePhone.DataKeys[e.Item.ItemIndex]);
            if (e.CommandName.Equals("ViewDeal"))
            {
                dlMobilePhone.Visible = false;
                frmMobileInfo.Visible = true;
                frmMobileInfo.DataSource = mobilePhoneBLL.View(id);
                frmMobileInfo.DataBind();
            }

        }
        catch (Exception )
        {

            // catch nothing 
        }

    }
}