﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Deals : System.Web.UI.Page
{
    protected MobilePhoneBLL mobilePhoneBLL = new MobilePhoneBLL();

    protected void Page_Load(object sender, EventArgs e)
    {
        LoadData();
    }

    /// <summary>
    /// Create funcation LoadData, which loads data to datalist via business logic layer (BLL) mobilePhoneBLL
    /// into a table
    /// </summary>
    protected void LoadData()
    { 
        dlMobilePhoneDeals.DataSource = mobilePhoneBLL.ViewAllDealsOnPhone();
        dlMobilePhoneDeals.DataBind();
    }


    /// <summary>
    /// set the datalist table funcations so when user click on view from a field it will go to asp.net formview form
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void dlMobilePhone_ItemCommand(object sender, DataListCommandEventArgs e)
    {
        try
        {
            //frmMobilePhone.Visible = false;
            int id = Convert.ToInt16(dlMobilePhoneDeals.DataKeys[e.Item.ItemIndex]);
            if (e.CommandName.Equals("ViewDeal"))
            {
                dlMobilePhoneDeals.Visible = false;
                frmMobileInfo.Visible = true;
                frmMobileInfo.DataSource = mobilePhoneBLL.View(id);
                frmMobileInfo.DataBind();
            }

        }
        catch (Exception)
        {


        }

    }



}