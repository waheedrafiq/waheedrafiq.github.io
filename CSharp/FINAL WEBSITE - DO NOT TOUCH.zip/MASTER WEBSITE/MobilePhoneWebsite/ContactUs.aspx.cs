﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Mail;
using System.Text;

public partial class Upgrades : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnEmail_Click(object sender, EventArgs e)
    {

        //set the table email from to none visible
        tblEmailForm.Visible = false;

        //define MailMessage 
        MailMessage msg = new MailMessage();

        //set the msg to string value
        msg.To = "waheedrafiq@outlook.com";

        //set the msg from string value
        msg.From = "web@gmvcommuncation.com";

        //set the email message subject
        msg.Subject = "You have a email from GMV Communcation Website";
        //define StringBuilder from System.Text.StringBuilder sb
        StringBuilder sb = new StringBuilder();
        //build the email message into StringBuilder
        sb.Append("<hr/>");
        sb.Append("<p>Name:" + txtName.ToString() + "</p>");
        sb.Append("<hr/>");
        sb.Append("<p>Email:" + txtEmail.ToString() + "</p>");
        sb.Append("<hr/>");
        sb.Append("<p>Phone:" + txtPhone.ToString() + "</p>");
        sb.Append("<hr/>");
        sb.Append("<p>Message:<br/>" + txtMessage.ToString() + "</p>");
        sb.Append("<hr/>");

        //set the mailMessage body content to string builder data
        msg.Body = sb.ToString();
        

        //display a message to end user 
        lblEmailMsg.Text = ("<span class='highlight'>Thank you for completing our online contact form. One of our staff will contact you very shortly</span>");

    }
}