﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ObjMobilePhone
/// </summary>
public class ObjMobilePhone
{
    protected int _mobilePhoneID;
    protected string _mobilePhoneModel;
    protected double _mobilePhonePrice;
    protected string _mobilePhoneFeatures;
    protected string _mobilePhoneDescription;
    protected int _mobilePhoneHome;
    protected int _mobilePhoneDeal;

    public ObjMobilePhone(object objMobilePhoneID, object objMobilePhoneModel, object objMobilePhonePrice, object objMobilePhoneFeatures, object objMobilePhoneDescription, object objMobilePhoneHome, object objMobilePhoneDeal)
	{
		_mobilePhoneID = Convert.ToInt16(objMobilePhoneID.ToString());
        _mobilePhoneModel = objMobilePhoneModel.ToString();
        _mobilePhonePrice = Convert.ToDouble(objMobilePhonePrice.ToString());
        _mobilePhoneFeatures = objMobilePhoneFeatures.ToString();
        _mobilePhoneDescription = objMobilePhoneDescription.ToString();
        _mobilePhoneHome = Convert.ToInt16(objMobilePhoneHome.ToString());
        _mobilePhoneDeal = Convert.ToInt16(objMobilePhoneDeal.ToString());
	}

    public int MobilePhoneID
    {
        get { return _mobilePhoneID; }
        set { _mobilePhoneID = value; }
    }

    public string MobilePhoneModel
    {
        get { return _mobilePhoneModel; }
        set { _mobilePhoneModel = value; }
    }

    public double MobilePhonePrice
    {
        get { return _mobilePhonePrice; }
        set { _mobilePhonePrice = value; }
    }

    public string MobilePhoneFeatures
    {
        get { return _mobilePhoneFeatures; }
        set { _mobilePhoneFeatures = value; }
    }

    public string MobilePhoneDescription
    {
        get { return _mobilePhoneDescription; }
        set { _mobilePhoneDescription = value; }
    }

    public int MobilePhoneHome
    {
        get { return _mobilePhoneHome; }
        set { _mobilePhoneHome = value; }
    }

    public int MobilePhoneDeal
    {
        get { return _mobilePhoneDeal; }
        set { _mobilePhoneDeal = value; }
    }
    
     
}