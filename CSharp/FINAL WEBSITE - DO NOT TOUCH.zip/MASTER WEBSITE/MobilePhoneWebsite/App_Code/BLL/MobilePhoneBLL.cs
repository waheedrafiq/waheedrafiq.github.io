﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;

/// <summary>
/// Create a Business Logic Layer (BLL) to manage the data.
/// </summary>
public class MobilePhoneBLL
{

    Linq.MobilePhoneLinqDataContext mobilePhoneLinq = new Linq.MobilePhoneLinqDataContext();
	public MobilePhoneBLL()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    /// <summary>
    /// Add data to the database using linq
    /// </summary>
    /// <param name="phoneModel"></param>
    /// <param name="picture"></param>
    /// <param name="price"></param>
    /// <param name="features"></param>
    /// <param name="description"></param>
    /// <param name="homePage"></param>
    /// <param name="phoneDeal"></param>
    /// <returns></returns>
    public Boolean Add(string phoneModel, byte[] picture, double price, string features, string description, int homePage, int phoneDeal)
    {
        try
        {
            Linq.tblMobilePhone mobilePhoneData = new Linq.tblMobilePhone();
            mobilePhoneData.mobile_phone_model = phoneModel;
            mobilePhoneData.mobile_phone_price = Convert.ToDecimal(price);
            mobilePhoneData.mobile_phone_features = features;
            mobilePhoneData.mobile_phone_description = description;
            mobilePhoneData.mobile_phone_image = picture;
            mobilePhoneData.mobile_phone_home = homePage;
            mobilePhoneData.mobile_phone_deal = phoneDeal;

            mobilePhoneLinq.tblMobilePhones.InsertOnSubmit(mobilePhoneData);
            mobilePhoneLinq.SubmitChanges();

            return true;
        }
        catch (Exception ex)
        {
            return false;
            //ex.Message.ToString();
        }
    }

    /// <summary>
    /// Update data in database via Linq
    /// </summary>
    /// <param name="id"></param>
    /// <param name="phoneModel"></param>
    /// <param name="picture"></param>
    /// <param name="price"></param>
    /// <param name="features"></param>
    /// <param name="description"></param>
    /// <param name="homePage"></param>
    /// <param name="phoneDeal"></param>
    /// <returns></returns>
    public Boolean Update(int id, string phoneModel, byte[] picture, double price, string features, string description, int homePage, int phoneDeal)
    {
        try
        {
            var mobilePhoneDataUpdate = mobilePhoneLinq.tblMobilePhones.Where(p => p.mobile_phone_id == id).SingleOrDefault();

            mobilePhoneDataUpdate.mobile_phone_model = phoneModel;
            if (picture.Count() != 0 || !string.IsNullOrEmpty(picture.Count().ToString()))
            {
                mobilePhoneDataUpdate.mobile_phone_image = picture;
            }
            mobilePhoneDataUpdate.mobile_phone_price = Convert.ToDecimal(price);
            mobilePhoneDataUpdate.mobile_phone_features = features;
            mobilePhoneDataUpdate.mobile_phone_description = description;
            mobilePhoneDataUpdate.mobile_phone_home = homePage;
            mobilePhoneDataUpdate.mobile_phone_deal = phoneDeal;
            
            mobilePhoneLinq.SubmitChanges();

            return true;
        }
        catch (Exception ex)
        {
            return false;
            //ex.Message.ToString();
        }
    }

    /// <summary>
    /// Delete a data where the ID value is met from database via LINQ
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public Boolean Delete(int id)
    {
        try
        {
            var mobileDataDelete = mobilePhoneLinq.tblMobilePhones.Where(p => p.mobile_phone_id == id).SingleOrDefault();
            mobilePhoneLinq.tblMobilePhones.DeleteOnSubmit(mobileDataDelete);
            mobilePhoneLinq.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            return false;
            //ex.Message.ToString();
        }
    }

    /// <summary>
    /// Build a arraylist from database using Object to store values where the ID is met
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public ArrayList View(int id )
    {
        ArrayList al = new ArrayList();
        try
        {
            var linqQuery = from p in  mobilePhoneLinq.tblMobilePhones where p.mobile_phone_id==id orderby p.mobile_phone_id descending select new {p.mobile_phone_id,p.mobile_phone_image,p.mobile_phone_model,p.mobile_phone_description,p.mobile_phone_features,p.mobile_phone_price, p.mobile_phone_home, p.mobile_phone_deal};

            foreach (var item in linqQuery)
            {
                 al.Add(new ObjMobilePhone(item.mobile_phone_id,item.mobile_phone_model,item.mobile_phone_price,item.mobile_phone_features,item.mobile_phone_description, item.mobile_phone_home, item.mobile_phone_deal));
            }                    
                                
              
        }
        catch (Exception ex)
        {

            ex.Message.ToString();
        }
        return al;
    }

    /// <summary>
    /// Build a arraylist from database using Object to store values
    /// </summary>
    /// <returns></returns>
    public ArrayList ViewAll()
    {
        ArrayList al = new ArrayList();
        try
        {
            var linqQuery = from p in mobilePhoneLinq.tblMobilePhones orderby p.mobile_phone_id descending select new { p.mobile_phone_id, p.mobile_phone_image, p.mobile_phone_model, p.mobile_phone_description, p.mobile_phone_features, p.mobile_phone_price,p.mobile_phone_home, p.mobile_phone_deal };

            foreach (var item in linqQuery)
            {
                al.Add(new ObjMobilePhone(item.mobile_phone_id, item.mobile_phone_model, item.mobile_phone_price, item.mobile_phone_features, item.mobile_phone_description,item.mobile_phone_home, item.mobile_phone_deal));
            }


        }
        catch (Exception ex)
        {

            ex.Message.ToString();
        }
        return al;
    }

    /// <summary>
    /// Build a arraylist from database using Object to store values from tblMobilePhones
    /// </summary>
    /// <returns></returns>
    public ArrayList ViewAllPhones()
    {
        ArrayList al = new ArrayList();
        try
        {
            var linqQuery = from p in mobilePhoneLinq.tblMobilePhones orderby p.mobile_phone_id descending select new { p.mobile_phone_id, p.mobile_phone_image, p.mobile_phone_model, p.mobile_phone_description, p.mobile_phone_features, p.mobile_phone_price,p.mobile_phone_home, p.mobile_phone_deal };

            foreach (var item in linqQuery)
            {
                al.Add(new ObjMobilePhone(item.mobile_phone_id, item.mobile_phone_model, item.mobile_phone_price, item.mobile_phone_features, item.mobile_phone_description,item.mobile_phone_home,item.mobile_phone_deal));
            }


        }
        catch (Exception ex)
        {

            ex.Message.ToString();
        }
        return al;
    }
    /// <summary>
    /// Build ArrayList from database storeing it into Object where tblMobilePhone feild mobile_phone_home=1
    /// </summary>
    /// <returns></returns>
    public ArrayList ViewAllPhoneOnHome()
    {
        ArrayList al = new ArrayList();
        try
        {
            var linqQuery = from p in mobilePhoneLinq.tblMobilePhones where p.mobile_phone_home==1 orderby p.mobile_phone_id descending select new { p.mobile_phone_id, p.mobile_phone_image, p.mobile_phone_model, p.mobile_phone_description, p.mobile_phone_features, p.mobile_phone_price,p.mobile_phone_home,p.mobile_phone_deal };

            foreach (var item in linqQuery)
            {
                al.Add(new ObjMobilePhone(item.mobile_phone_id, item.mobile_phone_model, item.mobile_phone_price, item.mobile_phone_features, item.mobile_phone_description,item.mobile_phone_home,item.mobile_phone_deal));
            }


        }
        catch (Exception ex)
        {

            ex.Message.ToString();
        }
        return al;
    }
    /// Build ArrayList from database storeing it into Object where tblMobilePhone feild mobile_phone_deal=1
    public ArrayList ViewAllDealsOnPhone()
    {
        ArrayList al = new ArrayList();
        try
        {
            var linqQuery = from p in mobilePhoneLinq.tblMobilePhones where p.mobile_phone_deal == 1 orderby p.mobile_phone_id descending select new { p.mobile_phone_id, p.mobile_phone_image, p.mobile_phone_model, p.mobile_phone_description, p.mobile_phone_features, p.mobile_phone_price, p.mobile_phone_home, p.mobile_phone_deal };

            foreach (var item in linqQuery)
            {
                al.Add(new ObjMobilePhone(item.mobile_phone_id, item.mobile_phone_model, item.mobile_phone_price, item.mobile_phone_features, item.mobile_phone_description, item.mobile_phone_home, item.mobile_phone_deal));
            }


        }
        catch (Exception ex)
        {

            ex.Message.ToString();
        }
        return al;
    }




}