﻿// Load system files for project
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Drawing;
using System.Drawing.Imaging;
using System.Data.SqlClient;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;


public partial class App_Images_MobilePhoneImage : System.Web.UI.Page
{
    // declare variables  _id and Linq Data Context name mobilePhoneLinq
    protected string _id;
    protected Linq.MobilePhoneLinqDataContext mobilePhoneLinq = new Linq.MobilePhoneLinqDataContext();


    //declared public fct bool
    public bool ThumbnailCallback()
    {
        return true;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //grab id value from web browser address bar
        _id = Request.QueryString["ID"];




        try
        {
            // declared image control
            System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();
            // query database via linq where id value is met with the queryString value
            var images = from p in mobilePhoneLinq.tblMobilePhones where p.mobile_phone_id == Convert.ToInt16(_id) select System.Drawing.Image.FromStream(new MemoryStream(p.mobile_phone_image.ToArray()));

            //build the image from database loop throw the image code
            foreach (System.Drawing.Image image in images)
            {
                //build up the image from database value
                System.Drawing.Image thumbnailImage = image.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                //delcar memoryStream
                MemoryStream imageStream = new MemoryStream();
                //save the image into memory stream
                thumbnailImage.Save(imageStream, ImageFormat.Jpeg);
                //declare byte based on memory stream length
                byte[] imageContent = new Byte[imageStream.Length];
                //set the image position to zerox
                imageStream.Position = 0;
                //read the image content from byte based on memory stream
                imageStream.Read(imageContent, 0, (int)imageStream.Length);
                //save the image as jpeg
                Response.ContentType = "image/jpeg";
                //write out the image file to page.
                Response.BinaryWrite(imageContent);

            }

        }
        catch (Exception ex)
        {
            //catch error message 
            ex.Message.ToString();
        }

    }
}