﻿//Import stand system files 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Dashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //check to see if the user is login as Admin and if not then redirect them to login page
        string chkLogin = (string)Session["access"];
        if (chkLogin != "true")
        {
            Response.Redirect("Login.aspx");
        }
    }
}