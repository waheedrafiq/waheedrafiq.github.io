﻿// Import standard system files 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_MobilePhone : System.Web.UI.Page
{
    protected MobilePhoneBLL mobilePhoneBLL = new MobilePhoneBLL();

    protected void Page_Load(object sender, EventArgs e)
    {
       //  password is not access then redirect to login.aspx page
        string chkLogin = (string)Session["access"];
        if (chkLogin != "true")
        {
            Response.Redirect("Login.aspx");
        }
       

        if (!IsPostBack)
        {
            LoadData();
        }

    }


    protected void LoadData()
    {
        try
        {
            dlMobilePhone.DataSource = mobilePhoneBLL.ViewAll();
            dlMobilePhone.DataBind();
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void dlMobilePhone_ItemCommand(object sender, DataListCommandEventArgs e)
    {
        try
        {
            frmMobilePhone.Visible = false;
            int id = Convert.ToInt16(dlMobilePhone.DataKeys[e.Item.ItemIndex]);
            if (e.CommandName.Equals("View"))
            {
                ViewFormData(id);
            }

        }
        catch (Exception)
        {


        }

    }

    protected void frmMobilePhone_ItemCommand(object sender, FormViewCommandEventArgs e)
    {
        int id = 0;
        try
        {
            //id = Convert.ToInt16(frmMobilePhone.DataKey.Value.ToString());
            Label lblMobilePhoneID = (Label)frmMobilePhone.FindControl("lblMobilePhoneID");
            id = Convert.ToInt16(lblMobilePhoneID.Text.ToString());

            if (String.IsNullOrEmpty(id.ToString()))
            {
                id = 1;
            }
        }
        catch (Exception ex)
        {
            id = 1;
            ex.Message.ToString();

        }


        try
        {
            if (e.CommandName.Equals("Add"))
            {
                AddFormData();
            }
            else if (e.CommandName.Equals("Update"))
            {
                UpdateFormData(id);
            }
            else if (e.CommandName.Equals("Delete"))
            {
                DeleteFormData(id);
            }
            else if (e.CommandName.Equals("View"))
            {
                ViewFormData(id);
            }
            else if (e.CommandName.Equals("Exit"))
            {
                ExitFormData();
            }
            else if (e.CommandName.Equals("Insert"))
            {
                InsertFormData();
            }
            else if (e.CommandName.Equals("Edit"))
            {
                EditFormData(id);
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }


    protected void frmMobilePhone_ModeChanging(Object sender, FormViewModeEventArgs e)
    {

        switch (e.NewMode)
        {
            case FormViewMode.Edit:
                break;

            case FormViewMode.ReadOnly:


                if (e.CancelingEdit)
                {
                    //MessageLabel.Text = "Update canceled.";
                }
                else
                {
                    //MessageLabel.Text = "Update completed.";
                }
                break;

            case FormViewMode.Insert:
                e.Cancel = true;
                break;
            default:

                break;

        }



    }

    protected void frmMobilePhone_ItemUpdating(Object sender, FormViewUpdateEventArgs e)
    {
        frmMobilePhone.DataBind();




    }


    protected void frmMobilePhone_ItemInserting(Object sender, FormViewInsertEventArgs e)
    {
        try
        {
            frmMobilePhone.DataBind();


        }
        catch (Exception)
        {


        }

    }



    protected void AddFormData()
    {
        TextBox txtMobilePhoneModel = (TextBox)frmMobilePhone.FindControl("txtMobilePhoneModel");
        FileUpload fupMobilePhonePicture = (FileUpload)frmMobilePhone.FindControl("fupMobilePhonePicture");
        TextBox txtMobilePhonePrice = (TextBox)frmMobilePhone.FindControl("txtMobilePhonePrice");
        TextBox txtMobilePhoneFeatures = (TextBox)frmMobilePhone.FindControl("txtMobilePhoneFeatures");
        TextBox txtMobilePhoneDescription = (TextBox)frmMobilePhone.FindControl("txtMobilePhoneDescription");
        CheckBox chkMobilePhoneHome = (CheckBox)frmMobilePhone.FindControl("chkMobilePhoneHome");
        CheckBox chkMobilePhoneDeal = (CheckBox)frmMobilePhone.FindControl("chkMobilePhoneDeal");

        int mobilePhoneHome;
        if (chkMobilePhoneHome.Checked)
        {
            mobilePhoneHome = 1;
        }
        else
        {
            mobilePhoneHome = 0;
        }


        int mobilePhoneDeal;
        if (chkMobilePhoneDeal.Checked)
        {
            mobilePhoneDeal = 1;
        }
        else
        {
            mobilePhoneDeal = 0;
        }

        int imageSize;
        string imageType;
        System.IO.Stream imageStream;

        // Gets the Size of the Image
        imageSize = fupMobilePhonePicture.PostedFile.ContentLength;

        // Gets the Image Type
        imageType = fupMobilePhonePicture.PostedFile.ContentType;

        // Reads the Image stream
        imageStream = fupMobilePhonePicture.PostedFile.InputStream;

        byte[] imageContent = new byte[imageSize];
        int intStatus;
        intStatus = imageStream.Read(imageContent, 0, imageSize);


        //mobilePhoneBLL.Add(txtMobilePhoneModel.Text.ToString(),imageContent);
        mobilePhoneBLL.Add(txtMobilePhoneModel.Text.ToString(), imageContent, Convert.ToDouble(txtMobilePhonePrice.Text.ToString()), txtMobilePhoneFeatures.Text.ToString(), txtMobilePhoneDescription.Text.ToString(), mobilePhoneHome,mobilePhoneDeal);
        Response.Redirect("MobilePhone.aspx");
    }

    protected void ViewFormData(int id)
    {

        dlMobilePhone.Visible = false;

        frmMobilePhone.Visible = true;
        frmMobilePhone.DefaultMode = FormViewMode.ReadOnly;
        frmMobilePhone.DataSource = mobilePhoneBLL.View(id);
        frmMobilePhone.DataBind();
        HiddenField hfMobilePhoneHome = (HiddenField)frmMobilePhone.FindControl("hfMobilePhoneHome");
        Label lblMobilePhoneHome = (Label)frmMobilePhone.FindControl("lblMobilePhoneHome");
        HiddenField hfMobilePhoneDeal = (HiddenField)frmMobilePhone.FindControl("hfMobilePhoneDeal");
        Label lblMobilePhoneDeal = (Label)frmMobilePhone.FindControl("lblMobilePhoneDeal");

        if (hfMobilePhoneHome.Value == "1")
        {
            lblMobilePhoneHome.Text = "Yes";
        }
        else
        {
            lblMobilePhoneHome.Text = "No";
        }

        if (hfMobilePhoneDeal.Value == "1")
        {
            lblMobilePhoneDeal.Text = "Yes";
        }
        else
        {
            lblMobilePhoneDeal.Text = "No";
        }

    }


    protected void UpdateFormData(int id)
    {
        try
        {
            TextBox txtMobilePhoneModel = (TextBox)frmMobilePhone.FindControl("txtMobilePhoneModel");
            FileUpload fupMobilePhonePicture = (FileUpload)frmMobilePhone.FindControl("fupMobilePhonePicture");
            TextBox txtMobilePhonePrice = (TextBox)frmMobilePhone.FindControl("txtMobilePhonePrice");
            TextBox txtMobilePhoneFeatures = (TextBox)frmMobilePhone.FindControl("txtMobilePhoneFeatures");
            TextBox txtMobilePhoneDescription = (TextBox)frmMobilePhone.FindControl("txtMobilePhoneDescription");
            HiddenField hfMobilePhoneHome = (HiddenField)frmMobilePhone.FindControl("hfMobilePhoneHome");
            CheckBox chkMobilePhoneHome = (CheckBox)frmMobilePhone.FindControl("chkMobilePhoneHome");
            HiddenField hfMobilePhoneDeal = (HiddenField)frmMobilePhone.FindControl("hfMobilePhoneDeal");
            CheckBox chkMobilePhoneDeal = (CheckBox)frmMobilePhone.FindControl("chkMobilePhoneDeal");

            int mobilePhoneHome;
            if (chkMobilePhoneHome.Checked)
            {
                mobilePhoneHome = 1;
            }
            else
            {
                mobilePhoneHome = Convert.ToInt16(hfMobilePhoneHome.Value.ToString());
            }

            int mobilePhoneDeal;
            if (chkMobilePhoneDeal.Checked)
            {
                mobilePhoneDeal = 1;
            }
            else
            {
                mobilePhoneDeal = Convert.ToInt16(hfMobilePhoneDeal.Value.ToString());
            }

            int imageSize;
            string imageType;
            System.IO.Stream imageStream;

            // Gets the Size of the Image
            imageSize = fupMobilePhonePicture.PostedFile.ContentLength;

            // Gets the Image Type
            imageType = fupMobilePhonePicture.PostedFile.ContentType;

            // Reads the Image stream
            imageStream = fupMobilePhonePicture.PostedFile.InputStream;

            byte[] imageContent = new byte[imageSize];
            int intStatus;
            intStatus = imageStream.Read(imageContent, 0, imageSize);


            //mobilePhoneBLL.Add(txtMobilePhoneModel.Text.ToString(),imageContent);
            mobilePhoneBLL.Update(id, txtMobilePhoneModel.Text.ToString(), imageContent, Convert.ToDouble(txtMobilePhonePrice.Text.ToString()), txtMobilePhoneFeatures.Text.ToString(), txtMobilePhoneDescription.Text.ToString(), mobilePhoneHome,mobilePhoneDeal);
            Response.Redirect("MobilePhone.aspx");

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

    protected void InsertFormData()
    {
        try
        {
            if (frmMobilePhone.CurrentMode.ToString() == "ReadOnly" || frmMobilePhone.CurrentMode.ToString() == "Edit")
            {
                frmMobilePhone.ChangeMode(FormViewMode.Insert);
                frmMobilePhone.DataBind();

            }
        }
        catch (Exception)
        {


        }

    }

    protected void EditFormData(int id)
    {
        try
        {
            if (frmMobilePhone.CurrentMode.ToString() == "ReadOnly")
            {

                frmMobilePhone.ChangeMode(FormViewMode.Edit);
                // int id = Convert.ToInt16(frmData.DataKey.Value.ToString());
                frmMobilePhone.DataSource = mobilePhoneBLL.View(id);
                frmMobilePhone.DataBind();

                HiddenField hfMobilePhoneHome = (HiddenField)frmMobilePhone.FindControl("hfMobilePhoneHome");
                CheckBox chkMobilePhoneHome = (CheckBox)frmMobilePhone.FindControl("chkMobilePhoneHome");
                if (hfMobilePhoneHome.Value == "1")
                {
                    chkMobilePhoneHome.Checked = true;
                }

                HiddenField hfMobilePhoneDeal = (HiddenField)frmMobilePhone.FindControl("hfMobilePhoneDeal");
                CheckBox chkMobilePhoneDeal = (CheckBox)frmMobilePhone.FindControl("chkMobilePhoneDeal");
                if (hfMobilePhoneDeal.Value == "1")
                {
                    chkMobilePhoneDeal.Checked = true;
                }
            }
        }
        catch (Exception)
        {

        }
    }

    protected void DeleteFormData(int id)
    {
        try
        {
            mobilePhoneBLL.Delete(id);
            Response.Redirect("MobilePhone.aspx");
        }
        catch (Exception)
        {

        }
    }

    protected void ExitFormData()
    {
        try
        {
            Response.Redirect("MobilePhone.aspx");
        }
        catch (Exception)
        {


        }


    }



    protected void btnAddNewMobilePhone_Click(object sender, EventArgs e)
    {

        dlMobilePhone.Visible = false;

        frmMobilePhone.Visible = true;
        frmMobilePhone.DefaultMode = FormViewMode.Insert;
    }
}