﻿// Import stand system files 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Logout : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //set the session access to false;
        Session["access"] = "false";
        Response.Redirect("Login.aspx");
        

    }
}