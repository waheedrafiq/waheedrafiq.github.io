﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;


public partial class App_Images_MobilePhoneImage : System.Web.UI.Page
{
    protected string _id;
    protected Linq.MobilePhoneLinqDataContext mobilePhoneLinq = new Linq.MobilePhoneLinqDataContext();


    public bool ThumbnailCallback()
    {
        return true;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        _id = Request.QueryString["ID"];




        System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();
        var images = from p in mobilePhoneLinq.tblMobilePhones where p.mobile_phone_id == Convert.ToInt16(_id) select System.Drawing.Image.FromStream(new MemoryStream(p.mobile_phone_image.ToArray()));


        foreach (System.Drawing.Image image in images)
        {

            System.Drawing.Image thumbnailImage = image.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
            MemoryStream imageStream = new MemoryStream();
            thumbnailImage.Save(imageStream, ImageFormat.Jpeg);
            byte[] imageContent = new Byte[imageStream.Length];
            imageStream.Position = 0;
            imageStream.Read(imageContent, 0, (int)imageStream.Length);
            Response.ContentType = "image/jpeg";
            Response.BinaryWrite(imageContent);
            // Response.OutputStream.Write(imageContent,0,0);
        }

    }
}