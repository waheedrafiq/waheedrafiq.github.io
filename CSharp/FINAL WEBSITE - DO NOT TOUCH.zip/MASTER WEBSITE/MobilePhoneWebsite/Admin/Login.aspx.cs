﻿// Import standard system files
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e) 
    {
        // if  Username is Admin && Password is access21 then redirect to Dashboard page.
        if (txtUsername.Text == "Admin" && txtPassword.Text == "access21")
        {
            Session["access"] = "true";
            Response.Redirect("Dashboard.aspx");

        }
        else 
        {
            // display in label control "Login Error " 
            Session["access"] = "false";
            lblMsg.Text = ("<span class='highlight'>Login Error!!!</span>");
        }
    }
}