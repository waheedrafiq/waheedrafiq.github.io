﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassExample
{
    class Peoples: Rules
    {

        private string Name { get; set; }
        private int age { get; set; }

        public Peoples()
        {
            this.Name = this.Name;
            this.age = this.age;
        }
       
        override
        public void  PrintMe(string name , int age)
        {
            Name = name;
            age = age;


            Console.WriteLine("Your name is {0}  and your age is {1}", Name, age);
            Console.Beep();
            Console.ReadKey();

        }
    }
}
