﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassExample
{
   abstract class Rules
    {
        private string Name;
        private int Age; 
        public abstract void PrintMe(string name, int age);
    }
}
