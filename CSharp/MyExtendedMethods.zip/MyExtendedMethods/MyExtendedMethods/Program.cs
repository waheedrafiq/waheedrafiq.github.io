﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyExtendedMethods
{

    // Example of Extension method 
    public static class MyExtendedMethods
    {
        public  static int square(this int numA)
        {
                 int result1 = 0;
                 result1 = numA* numA;
                 return result1;
        }
    }
    // end of my extension method.


   

    class Program
    {
        // calculate rectangle  area
        public static double rectArea(double length, double width)
        {
            return length * width; // L * W provides you with area of rectangle.
        }
        static void Main(string[] args)
        {
            int MyNum = 3;
            double  resultArea;
            MyNum = MyNum.square();

            Console.WriteLine("Your square is : "+ MyNum);
            Console.ReadKey();

            // possible graphics

            // example of named arguments
            resultArea = rectArea(length: 20.5, width: 25.9);// notices : 

            Console.Write("The calcaluated Area is : " + resultArea);
            Console.ReadKey();



        }
    }
}
