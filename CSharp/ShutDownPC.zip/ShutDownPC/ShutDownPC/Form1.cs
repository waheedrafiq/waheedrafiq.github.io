﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Management;
using System.Runtime.InteropServices;

// add voice command

using System.Speech.Recognition;
using System.Speech.Synthesis;



namespace ShutDownPC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async Task InstallVoiceCommandsAsync()
        {
           
            
            var storageFile = await StorageFile.GetFileFromApplicationUriAsync(new Uri("ms-appx:///Cortana.xml"));

            await VoiceCommandManager.InstallCommandSetsFormStorageFileAsync(storageFile);

        }




        private void btnShutdown_Click(object sender, EventArgs e)
        {

            DialogResult result1 = MessageBox.Show("Are you Sure", "Shut down",MessageBoxButtons.OKCancel);
            // shutdown PC 
            if(DialogResult == DialogResult.OK)
            {
                System.Diagnostics.Process.Start("Shutdown", "-s -t 10");
            }
            else
            {
                MessageBox.Show("As you wish");
            }
            
            

        }
    }
}
