﻿//  Author: Waheed Rafiq
//  Date:   29/10/2015
//  File:   Main file SounddexApplication.cs
//
// class definition :EncodingWords.cs
// Application A word is encoded by replacing its letters with the corresponding group code.
// www.waheedrafiq.net 
//Student ID: S13189954
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace SounddexApplication
{
    class EncodingWordsArray
    {
        // Declare variables 
        private string[] group = new string[7]; // Array of  group with index 7
        private string sDisplay; // String to display user interface.
        private string ScreenName1, ScreenName2; // String to store ScreenName from Twitter.
        private int[] SoundDexV = new int[100]; // Temporary whole number array to store SoundDex index value.
        // Constructor to intialise Array Group
        public EncodingWordsArray()
        {
            this.group[0] = "A,E,I,O,U,H,W,Y";
            this.group[1] = "B,F,P,V";
            this.group[2] = "C,G,J,K,Q,S,X,Z";
            this.group[3] = "D,T";
            this.group[4] = "L";
            this.group[5] = "M,N";
            this.group[6] = "R";

        }
        // GroupCodeEncoding , read user input and encode string to SoundDex.
        public void GroupCodeEncoding()
        {
            bool exit = true; // Initalise exit.
            Console.Beep(); // Beep once so user knows application is active. 
            Console.Clear(); // clear previous contexts. 
            Console.ForegroundColor = ConsoleColor.Green; // Change the foreground colour to green.
            sDisplay = "\nAuthor: Waheed Rafiq | Student ID: S13189954";
            sDisplay += "\n _________________________________________________________________________";
            sDisplay += "\n|                  SoundDex Application Version 1.0                       |";
            sDisplay += "\n|_________________________________________________________________________|";
            sDisplay += "\n";
            sDisplay += "\n";
            sDisplay += "\n";
            Console.WriteLine(sDisplay);// Display user interface.
            // Change fore ground colour to white.
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("\nPlease type a word to be encoded ==> ");
            // Store user input into char data type tempStr1 array.
            char[] tempStr1 = Console.ReadLine().ToUpper().ToCharArray();

            // ==================================================
            //  Check to see if there are any digits for tempStr1
            //===================================================

            do
            {
                exit = true; // reset exit to true if its not already.
                // Loop through tempStr1
                foreach (char ch in tempStr1)
                {// Check if its a Digit
                    if (char.IsDigit(ch))
                    {
                        Console.Write("Invalid character detected entre valid character ==>");
                        tempStr1 = Console.ReadLine().ToUpper().ToCharArray();
                        exit = false; // exit is false not to exit the loop.
                        break;
                    }
                }// end of for each 
            } while (exit==false); // keep looping while exit is equal to false.

            Console.Write("\nPlease type a second word to be encoded ==>");
            // Store user input into char data type tempStr2 array.
            char[] tempStr2 = Console.ReadLine().ToUpper().ToCharArray();

            // ==============================================
            //  Check to see if there are any digits tempStr2
            //===============================================
            do
            {
                exit = true;// reset exit to true if its not already.
                // Loop through tempStr1
                foreach (char ch in tempStr2)
                { // check if there are any Digits
                    if (char.IsDigit(ch))
                    {
                        Console.Write("Invalid character detected entre valid character ==>");
                        tempStr2 = Console.ReadLine().ToUpper().ToCharArray();
                        exit = false; // exit is false not to exit the loop.
                        break;
                    }// End of if check statement.

                }// end of for each 
            } while (exit == false); // Keep looping while exit is false.
            

            Console.WriteLine("\n");
            DrawLineHorizontal();// Call upon the DrawBox method. 
            Console.WriteLine("\n"); // Add a blank line.
            // Format string to add 4 tabs 
            Console.WriteLine("First input" + "\t\t\t\t" + "Second Input");

            //============================================
            //    check first user input temStr1
            //============================================
            // Declare variable data type integer p , initialize value.
            int p = 0;

            for (int i = 0; i < tempStr1.Length; i++) // Loop until end of tempStr1 length.
            {
                for (int b = 0; b < 7; b++) //Loop until end of Index array 7 of group. 
                {
                    // if tempStr1 contains something from group array then condition is true.
                    if (group[b].Contains(tempStr1[i]))
                    {//  if index b is not null 
                        if (b != 0)
                        {
                            // assign element value to SoundDexV and increment p.
                            SoundDexV[p] = b;
                            p++;
                        }// End of null check.
                    }// End of condition check 

                }//End of for loop for Index array.
                // Print out tempStr1 index value.
                Console.Write(tempStr1[i] + " ");
            }//End of for loop for  tempStr1 lenght. 
            // Write string for user interface.
            Console.Write("Encoding value is: ");
            // Loop until i is less than p.
            for (int i = 0; i < p; i++)
            {//  if  value of i is equivalent to i then plus 1.
                if (SoundDexV[i] == SoundDexV[i + 1])
                {
                    //do nothing 
                }
                else
                {
                    // write the vaule of SoundDexV.   
                    Console.Write(SoundDexV[i]);
                }
            }
            // Write two tabs for user interface.  
            Console.Write("\t\t");

            //=====================================
            //    check second user input tempStr2
            //=====================================
            // Declare variable data type integer z , initialize value.
            int z = 0;

            for (int i = 0; i < tempStr2.Length; i++) // Loop until end of tempStr2 length.
            {
                //Loop until end of Index array 7 of group. 
                for (int b = 0; b < 7; b++)
                {
                    // If tempStr2 contains something from group array then condition is true.
                    if (group[b].Contains(tempStr2[i]))
                    {// If index b is not null. 
                        if (b != 0)
                        {
                            // assign element value to SoundDexV and increment z.
                            SoundDexV[z] = b;
                            z++;
                        }// End of null check.
                    }// End of condition check 
                }//End of for loop for Index array.
                Console.Write(tempStr2[i] + " "); // print tempStr2 string
            }// end of for statement 
            // Write string for user interface.
            Console.Write("Encoding value is: ");
            // Loop until i is less than p.
            for (int i = 0; i < p; i++)
            {//  if  value of i is equivalent to i then plus 1.
                if (SoundDexV[i] == SoundDexV[i + 1])
                {
                    //Do nothing 
                }
                else Console.Write(SoundDexV[i]);// write the vaule of SoundDexV.
            }
            Console.ReadKey();// Pause for User input to end the program.
        }// end of GroupCodeEncoding method. 

        // Twitter API screen name encoding to SoundDex method.
        public void TweetScreenNameInterface()
        {
            Console.Beep(); // Beep once for user awareness of application present. 
            Console.Clear(); // Clear previous contexts. 
            Console.ForegroundColor = ConsoleColor.Green; // Change the foreground colour to green.
            sDisplay = "\nAuthor: Waheed Rafiq | Student ID: S13189954";
            sDisplay += "\n _________________________________________________________________________";
            sDisplay += "\n|                  Twitter API SoundDex Screen Name v1.1                  |";
            sDisplay += "\n|_________________________________________________________________________|";
            sDisplay += "\n";
            sDisplay += "\n";
            sDisplay += "\n";
            // Write sDisplay to the console.
            Console.WriteLine(sDisplay);

        } // end of TweetDisplay 

        // ==========================================
        //      Twitter Screen Name  Encoding method
        // =========================================
        public void TwitterScreenNameEncoding()
        {
            TweetScreenNameInterface(); // call the twitter display interface.
            // Create new object GetUserName pass empty string.
            Twitter GetUserName = new Twitter("");
            // Change fore ground colour to white. 
            Console.ForegroundColor = ConsoleColor.White;
            // Assign value from GetUserName.GetFirstTweet method to UserName1 string datatype.
            // Call GetUserName.GetSecondTweet return UserName1 value back to UserName1.
            ScreenName1 = GetUserName.GetFirstTweet(ScreenName1);
            // Convert the UserName1 to Char array tempStr1.
            char[] tempStr1 = ScreenName1.ToUpper().ToCharArray();
            // Assign value from GetUserName.GetSecondTweet method to UserName2 string datatype.
            // Call GetUserName.GetSecondTweet return UserName2 value back to UserName2.
            ScreenName2 = GetUserName.GetSecondTweet(ScreenName2);
            // Convert the UserName2 to Char array tempStr2.
            char[] tempStr2 = ScreenName2.ToUpper().ToCharArray();
            DrawLineHorizontal();// call upon the DrawBox method. 
            Console.WriteLine("\n"); // add a blank line.
            // Write string for user interface.
            Console.WriteLine("First twitter username:");

            //============================================
            //    check first user input temStr1
            //============================================
            // Declare variable data type integer p , initialize value.
            int p = 0;

            for (int i = 0; i < tempStr1.Length; i++) // Loop until end of tempStr1 length.
            {//Loop until end of Index array 7 of group. 
                for (int b = 0; b < 7; b++)
                {
                    // If tempStr2 contains something from group array then condition is true.
                    if (group[b].Contains(tempStr1[i]))
                    {// If index b is not null. 
                        if (b != 0)
                        { // Assign element value to SoundDexV and increment p.
                            SoundDexV[p] = b;
                            p++;
                        }// End of null check.
                    }// End of condition check 
                }//End of for loop for Index array.
                Console.Write(tempStr1[i] + " ");// print tempStr1 string
            }// end of for statement 
            // Write a blank new line.
            Console.WriteLine("\n");
            Console.Write("Encoding value is: "); // Write string for user interface.
            // Loop until i is less than p. 
            // Write the Numberic value of group array.
            for (int i = 0; i < p; i++)
            {//If  value of i is equivalent to i then plus 1.
                if (SoundDexV[i] == SoundDexV[i + 1])
                {
                    //do nothing 
                }
                else
                {
                    Console.Write(SoundDexV[i]);// write the vaule of SoundDexV.
                }// End of if statement check. 
            }// End of for loop.
            Console.Write("\n"); // Add tab for second line 

            //=======================================
            //    check second user input tempStr2
            //=======================================
            // Write blank line. 
            Console.WriteLine("\n");
            // Write string for user interface.
            Console.WriteLine("Second twitter username: ");
            // Declare variable data type integer z , initialize value.
            int z = 0;
            for (int i = 0; i < tempStr2.Length; i++) // Loop until end of tempStr2 length.
            {//Loop until end of Index array 7 of group.
                for (int b = 0; b < 7; b++)
                {
                    // If tempStr2 contains something from group array then condition is true.
                    if (group[b].Contains(tempStr2[i]))
                    {    // if b is not null
                        if (b != 0)
                        {
                            SoundDexV[z] = b;// Store the vaule of  b to SoundDexV[index].
                            z++; // and increment z.
                        } // End of If not null statement.
                    }// End of if statement. 
                }//End of for loop for Index Array.
                Console.Write(tempStr2[i] + " "); // print tempStr2 string
            }// End of for loop tempStr2 lenght.
            // Write a blank line.
            Console.WriteLine("\n");
            Console.Write("Encoding value is: ");
            // Loop until i is less than p.
            // print out the numberic value of group.
            for (int i = 0; i < p; i++)
            {//If  value of i is equivalent to i then plus 1.
                if (SoundDexV[i] == SoundDexV[i + 1])
                {
                    //do nothing 
                }
                else Console.Write(SoundDexV[i]);// write the vaule of SoundDexV.
            }
            PlaySound(); //Play star wars tone for user experience.
            Console.ReadKey();// Wait for user to press the any key to exit progam.
        }
        //=====================================================
        //  METHOD    Draw a Horizontal line 
        //=====================================================
        public void DrawLineHorizontal() // Method does not pass value 'void' is used.
        {// Console Window Width value is assign to datatype int width.
            int width = Console.WindowWidth;
            // Loop  until i is not true.
            for (int i = 0; i < width; ++i)
            {// Write to Console = each time , ensure fore ground color is green.
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("=");
            }
        }// End of DrawLine method 
        // GetInt() ensure user enters a integer value, keep prompting until Integer is entered

        

        //===========================
        //  METHOD    Play Sound
        //===========================
        // Play sound 
        public void PlaySound()
        {// The Imperial March tune. for user experience.
            // Credits to http://www.computersand.me/
            Console.Beep(440, 500);
            Console.Beep(440, 500);
            Console.Beep(440, 500);
            Console.Beep(349, 350);
            Console.Beep(523, 150);
            Console.Beep(440, 500);
            Console.Beep(349, 350);
            Console.Beep(523, 150);
            Console.Beep(440, 1000);
            Console.Beep(659, 500);
            Console.Beep(659, 500);
            Console.Beep(659, 500);
            Console.Beep(698, 350);
            Console.Beep(523, 150);
            Console.Beep(415, 500);
            Console.Beep(349, 350);
            Console.Beep(523, 150);
            Console.Beep(440, 1000);
        }// End of PlaySound method.

        //=================================
        //     User Menu Interface
        //=================================
        public int Menu(int v)
        {

            Console.TreatControlCAsInput = false; // disable  Ctrl+C 
            // If user press Cancel Key call upon breakhandler method. 
            Console.CancelKeyPress += new ConsoleCancelEventHandler(BreakHandler);
            // Clear any previous text 
            Console.Clear();
            // Set the Cursor to false so user can't see it.
            Console.CursorVisible = false;
            // Console Tile is SoundDex Application.
            Console.Title = "SoundDex Application";
            // Datatype MenuItem array , add the following element to array.
            string[] MenuItems = { "SoundDex Application", "Tweet SoundDex", "Credits", "Quit Application" };
            // Call ConsoleColorString method pass the following string /with console configuration.
            ConsoleColorString("\nAuthor: Waheed Rafiq | Student ID: S13189954", 8, 25, ConsoleColor.Black, ConsoleColor.White);
            ConsoleColorString("Choose option using down and up arrow keys and press enter", 8, 10,
            ConsoleColor.Black, ConsoleColor.White); // Position each string on Console
            ConsoleColorString("The purpose of this application is encoded a word by", 8, 13,
            ConsoleColor.Black, ConsoleColor.White);
            ConsoleColorString("replacing its letters with the corresponding group code.", 8, 17,
            ConsoleColor.Black, ConsoleColor.White);
            // Draw the listbox and place the element at postion 34, 3 , box color blue , text white 
            int choice = DrawListBoxItem(MenuItems, 25, 3, ConsoleColor.Blue, ConsoleColor.White);
            CleanUp();// Clear the screen 
            return choice; // Return user choice.
        }
        //================================
        //         Draw List Box
        //===============================

        public static int DrawListBoxItem(string[] MenuItems, int ucol, int urow, ConsoleColor back, ConsoleColor fore)
        {
            // Declare varables used.
            int numItems = MenuItems.Length; // MenuItem length sort value in numItems
            int maxLength = MenuItems[0].Length;
            int[] rightSpaces = new int[numItems];
            // Loop until i is not less than numItems. 
            for (int i = 1; i < numItems; i++)
            {// MenuItem length is greather than max length
                if (MenuItems[i].Length > maxLength)
                { //  Error handle max lenght is equal to menuItem length.
                    maxLength = MenuItems[i].Length;
                }// End of If statement.
            }// end of For each loop.

            // Loop until i is not less than numItems.
            for (int i = 0; i < numItems; i++)
            {// Max Lenght minus MenuItem lenght plus 1 will provide correct rightSpace on Console screen.
                rightSpaces[i] = maxLength - MenuItems[i].Length + 1;
            }// end of for Loop.
            // Column Plus max Lenght Plus 3.
            int lcol = ucol + maxLength + 3;
            // Row plus numItems plus 1.
            int lrow = urow + numItems + 1;
            // Call DrawBox method , pass values.
            DrawBox(ucol, urow, lcol, lrow, back, fore, true);
            // Call Console Color String  add blank space follow by rightSpace / Column plus 1 fore color back.
            ConsoleColorString(" " + MenuItems[0] + new string(' ', rightSpaces[0]), ucol + 1, urow + 1, fore, back);
            // Loop until i is less equal to numItems
            for (int i = 2; i <= numItems; i++)
            {// Call the method, pass the following values.
                ConsoleColorString(MenuItems[i - 1], ucol + 2, urow + i, back, fore);
            }// end of for statement.
            // Describes the console key that was pressed.
            ConsoleKeyInfo cki;
            char key;
            int choice = 1;
            // Keep looping until true.
            while (true)
            {
                cki = Console.ReadKey(true);
                key = cki.KeyChar;
                if (key == '\r') // If the key 'Enter' is press.
                {
                    return choice;
                }// Navigation: if user press down arrow key 
                else if (cki.Key == ConsoleKey.DownArrow)
                {// Format the string 
                    ConsoleColorString(" " + MenuItems[choice - 1] + new string(' ', rightSpaces[choice - 1]), ucol + 1, urow + choice, back, fore);
                    if (choice < numItems)
                    {
                        choice++;
                    }
                    else
                    {// Else go back to first element. 
                        choice = 1;
                    }
                    ConsoleColorString(" " + MenuItems[choice - 1] + new string(' ', rightSpaces[choice - 1]), ucol + 1, urow + choice, fore, back);

                }// Navigation : if User press upArrow key 
                else if (cki.Key == ConsoleKey.UpArrow)
                {// Move Up 
                    ConsoleColorString(" " + MenuItems[choice - 1] + new string(' ', rightSpaces[choice - 1]), ucol + 1, urow + choice, back, fore);
                    if (choice > 1)
                    {
                        choice--;
                    }
                    else
                    {
                        choice = numItems;
                    }
                    ConsoleColorString(" " + MenuItems[choice - 1] + new string(' ', rightSpaces[choice - 1]), ucol + 1, urow + choice, fore, back);
                }
            }
        }// End of Draw list box item.
        //================================
        //            Draw the Box Method
        //=================================
        public static void DrawBox(int ucol, int urow, int lcol, int lrow, ConsoleColor back, ConsoleColor fore, bool fill)
        { // Declare Const variable as they won't change UTF-16 unit code. 
            // this ensure correct layout for the box.
            const char Horizontal = '\u2500';
            const char Vertical = '\u2502';
            const char UpperLeftCorner = '\u250c';
            const char UpperRightCorner = '\u2510';
            const char LowerLeftCorner = '\u2514';
            const char LowerRightCorner = '\u2518';
            string fillLine = fill ? new string(' ', lcol - ucol - 1) : "";
            SetColors(back, fore);
            // Draw the top Edge 
            Console.SetCursorPosition(ucol, urow);
            Console.Write(UpperLeftCorner);
            for (int i = ucol + 1; i < lcol; i++)
            {
                Console.Write(Horizontal);
            }
            Console.Write(UpperRightCorner);

            // Draw sides. 
            for (int i = urow + 1; i < lrow; i++)
            {
                Console.SetCursorPosition(ucol, i);
                Console.Write(Vertical);
                if (fill) Console.Write(fillLine);
                Console.SetCursorPosition(lcol, i);
                Console.Write(Vertical);
            }
            // Draw bottom edge. 
            Console.SetCursorPosition(ucol, lrow);
            Console.Write(LowerLeftCorner);
            for (int i = ucol + 1; i < lcol; i++)
            {
                Console.Write(Horizontal);
            }
            Console.Write(LowerRightCorner);
        }// End of DrawBox method. 

        //============================
        //  Format Color String method.
        // =============================
        public static void ConsoleColorString(string s, int col, int row, ConsoleColor back, ConsoleColor Gray)
        { // Call SetColor method pass the colour values.
            SetColors(back, Gray);
            // Write string 
            Console.SetCursorPosition(col, row);
            Console.Write(s);
        }// end of Console Color String. 

        //============================
        //   Set Color Method 
        //============================
        public static void SetColors(ConsoleColor black, ConsoleColor Gray)
        {// Console Background colour will black. 
            Console.BackgroundColor = black;
            // Console foreground color will be gray. 
            Console.ForegroundColor = ConsoleColor.Gray;
        }
        //==========================
        //    Clean up Method 
        // ==========================
        public static void CleanUp()
        {// Reset the colour , cursor will be visible and clear the console with any texts.
            Console.ResetColor();
            Console.CursorVisible = true;
            Console.Clear();
        }

        //=================================
        //   Console Cancel Event Method
        //=================================

        private static void BreakHandler(object sender, ConsoleCancelEventArgs args)
        {
            // Clean up console screen. 
            CleanUp();
        }// End of BreakHandler method.

        //=========================
        //  Credits Method
        //=========================
        public void credits()
        { // This Method provides information and Credits to those that made this application possible.
            // All CopyRight are Reserved (c). 
            sDisplay = "\nAuthor: Waheed Rafiq | Student ID: S13189954";

            Console.ForegroundColor = ConsoleColor.Magenta;
            sDisplay += "\n _________________________________________________________________________";
            sDisplay += "\n|                          Credits                                        |";
            sDisplay += "\n|_________________________________________________________________________|";
            sDisplay += "\n";
            sDisplay += "\n";
            sDisplay += "\n";
            sDisplay += "\nSpecial Thanks to Dr Boyd for teaching C#";
            sDisplay += "\nSpecial Thanks to Dr Sarna for extra tips on using Visual Studio 2015.";
            sDisplay += "\nCredits to http://www.c-sharpcorner.com/  for using their " + "\ntutorial on console Listbox";
            sDisplay += "\nCredits to Twitter Plc for using their API: " + "\n https://dev.twitter.com/rest/reference/get/friends/ids";
            sDisplay += "\n Credits to :http://www.computersand.me/  for console.beep tune for The Imperial March tune. ";
            sDisplay += "\nfor user experience.";
           
            Console.WriteLine(sDisplay);
            Console.ReadKey();

        }// End of Credits Method. 

        

     }// end of class 

}// end of namespace 



