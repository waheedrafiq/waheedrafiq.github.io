﻿//  Author: Waheed Rafiq
//  Date:   29/10/2015
//  File:   Main file SounddexApplication.cs
//
//  class definition :Twitter.cs
// Application: This class  retrieves ScreenName from twitter user waheedrafiq33 and encoded 
// a word from the ScreenName.
// www.waheedrafiq.net 
//Student ID: S13189954

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TweetSharp; // Import API TweetSharp 
using Newtonsoft.Json; // import NewtonSoft required for TweetSharp API


namespace SounddexApplication
{
    class Twitter
    {
        // Declare Twitter developer access API token , token secret , consumer key , consumer secret. 
        // The account use for this section of the code is twitter account waheedrafiq33.
        // All ScreenName are being retrieve from waheedrafiq33 twitter account.
        //The Keys are not to be used for anyother purpose other than this application.
        // 
        private string Access_Token = "167742066-5mzztIfAZ8w2uBivdt5LGFOCEma71KnwaiOFUBL0";
        private string Access_Token_Secret = "s1bRLRoXXIa1xu5XZdydFRFgM96yAjGjdLm85AIZ5271q";
        private string Consumer_Key = "rH8Ry0wpmEzWvBS6Sr3B1EYHa";
        private string Consumer_Secret = "Jq6sVbYrxlnIWteHkZKav4rEM5cjF331NY1MqpCXOkz8kOE9ez";
        private string tempStr1,tempStr2;
        
        // first constructor 
        public Twitter(string s)
        {
            this.tempStr1 = s;
        }
       //=============================================
        //  Method for Getting first tweet Screen name
        //============================================
        public string GetFirstTweet(string s)
        {
            try
            {
                // let  the compiler determines the type  , apply TwitterService API (pass two keys) 
                var service = new TwitterService(Consumer_Key, Consumer_Secret);
                service.AuthenticateWith(Access_Token, Access_Token_Secret); // pass the next two keys for API
                // let the compiler determines the type ,
                var tweets = service.ListTweetsOnHomeTimeline(new ListTweetsOnHomeTimelineOptions());
                // For user interface display information.
                Console.Write("Getting ScreenNames for twitter...." + "\n");
                // Let the compiler determine the type , loop in Array tweets
                    foreach (var tweet in tweets)
                    {
                        tempStr1 = tweet.User.ScreenName; // Assign the ScreenName to tempStr1
                        if (tempStr1 != null) // if it is not null then return tempStr1
                        {
                            return tempStr1; 
                        }// end of if check 
                    } // end of for each first tweet 
               }// end of while exit loop.
            catch(Exception e) // if there is Exception display message for user information. 
            {
                Console.WriteLine("\nTwitter only allows 200 screenName please wait for 15 minutes... " + e);
            }
           return tempStr1;
        }// end of GetFirstTweet() method 
        //=============================================
        //  Method for Getting Second tweet Screen name
        //============================================
        public string GetSecondTweet(string s)
        {
            try
            {
                // let  the compiler determines the type  , apply TwitterService API (pass two keys) 
                var service = new TwitterService(Consumer_Key, Consumer_Secret);// pass the next two keys for API
                // let the compiler determines the type ,
                service.AuthenticateWith(Access_Token, Access_Token_Secret);
                // let the compiler determines the type call object ListTweetsOnHomeTimelineOptions.
                var tweets = service.ListTweetsOnHomeTimeline(new ListTweetsOnHomeTimelineOptions());
                // For user interface display information.
                    foreach (var tweet in tweets)
                    {
                        tempStr2 = tweet.User.ScreenName; // Assign the ScreenName to tempStr1
                        if (tempStr2 != null)// if tempStr2 is not empty 
                        {
                            // then compare the two values if not the same return tempStr2
                            if(tempStr2.Contains(tweet.User.ScreenName) != tempStr1.Contains(tweet.User.ScreenName))
                            return tempStr2;
                        }// end of if tempStr1 != null 
                    } // end of for each first tweet 
                }// end of while exit loop.
            catch (Exception e)// if there is Exception display message for user information. 
            {
                Console.WriteLine("\nTwitter only allows 200 screenName please wait for 15 minutes. " + e);
            }
            return tempStr2;
        }// end of tweetFriendsList
  }// end of  twitter class 
}// end of namespace twitter 
