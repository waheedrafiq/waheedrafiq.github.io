﻿//  Author: Waheed Rafiq
//  Date:   29/10/2015
//  File:   Main file SounddexApplication.cs
//
//  class definition :SounddexApplication
// Application: A word is encoded by replacing its letters with the corresponding group code.
// www.waheedrafiq.net 
//Student ID: S13189954
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace SounddexApplication
{
    class SounddexApplication
    {
        internal EncodingWordsArray EncodingWordsArray
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        internal Twitter Twitter
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    
        static void Main(string[] args)
        {
            // Declare new object SoundDex
            EncodingWordsArray SoundDex = new EncodingWordsArray();
            // Declare new object tweetR and pass empty string.
            Twitter tweetR = new Twitter("");
            // declare local varaibles to be used for menu choice
            int choice = 0;  
            // In this section of the code a switch case is not use because
            // there are only 3 items to choose from also K.I.S theory was apply here.
            do
            {
               // Return menu choice from menu method.
                choice = SoundDex.Menu(choice);
                // if choice is 1 is selected from SoundDex.Menu 
                if (choice == 1)
                {
                    // Call SoundDex.GroupCodeEncoding() method. 
                    SoundDex.GroupCodeEncoding();
                }
                else if(choice == 2) // If user input is choice 2 from the menu.
                {
                    // Call SoundDex.TwitterScreenNameEncoding() method.
                    SoundDex.TwitterScreenNameEncoding();
                }
                else if(choice == 3) // If user input is choice 3 run SoundDex.credits() method.
                {
                    SoundDex.credits();
                }
                else if (choice == 4) // If user Input choice is 4 , exit program. 
                {
                    Console.WriteLine("Press Any Key to exit !");
                    Thread.Sleep(2000); // Wait for two second.
                }

            } while (choice != 4); //Keep looping until choice is not 4
                // End of while loop. 
            Console.ReadKey();

        } // End of main class
    } // End of SounddexApplication class
}// End of namespace SounddexApplication
