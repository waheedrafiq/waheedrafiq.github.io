﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using System.IO;
using System.Net;

namespace MajesticSEO.External.RPC
{
    class Program
    {
        static void Main(string[] args)
        {
            string pathString = System.IO.Path.Combine(@"D:/", "AstonHack");
            System.IO.Directory.CreateDirectory(pathString);
            string endpoint = "http://enterprise.majesticseo.com/api_command";
            string app_api_key = "24037E51548A9F1A5E78D1FCFE3A2CD7";
            // string app_api_key = Console.ReadLine();

            Console.WriteLine(
                "\nPlease enter the list of items you wish to query seperated by "
                + "commas: \n(e.g. majesticseo.com, majestic12.co.uk)");

            string itemsToQuery = Console.ReadLine();
            string[] items = Regex.Split(itemsToQuery, ", ");

            

            /* create a Dictionary from the resulting array with the key being
             * "item0 => first item to query, item1 => second item to query" etc */
            Dictionary<string, string> parameters = new Dictionary<string, string>();
            for (int i = 0; i < items.Length; i++)
            {
                parameters.Add("item" + i, items[i]);
            }

            // add the total number of items to the Dictionary with the key being "items"
            parameters.Add("items", items.Length.ToString());

            parameters.Add("datasource", "fresh");
            APIService apiService = new APIService(app_api_key, endpoint);
            Response response = apiService.ExecuteCommand("GetIndexItemInfo", parameters);

           

            DataTable results = response.GetTableForName("Results");
            System.IO.File.WriteAllText(@"D:\AstonHack\Data.txt", string.Empty);
            BigInteger X=1;
            foreach (Dictionary<string, string> row in results.GetTableRows())
            {
                string item = row["Item"];
                Console.WriteLine("\n<" + item + ">");

                List<string> keys = new List<string>(row.Keys);
                keys.Sort();

                foreach (string key in keys)
                {
                    if (!key.Equals("item"))
                    {
                        string value = row[key];
                        if (key == "ExtBackLinks" || key == "TrustFlow" || key == "RefDomains")
                        {
                            using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"D:\AstonHack\Data.txt", true))
                            {
                                //file.WriteLine("Fourth line");

                                //file.WriteLine(" " + key + " ... " + value);
                                if (value != "0")
                                {

                                    BigInteger Value = Convert.ToInt64(value);
                                    X = X * Value;
                                }
                            }

                        }
                        
                    }
                    
                }
                 //string link = "http://facebook.com/favicon.ico";
                string link = "http://";
                link = link + item + @"/favicon.ico";
                string destFile = @"D:\AstonHack\favicon";
                destFile = destFile + item + ".ico";
                WebClient client = new WebClient();
                Console.WriteLine(link);
                Console.WriteLine(destFile);
                Console.ReadLine();

                client.DownloadFileAsync(new Uri(link), destFile);
               
                if (X != 1)
                {
                    
                    using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"D:\AstonHack\Data.txt", true))
                    {
                        file.WriteLine(item);
                        
                        X = X.ToString().Length;
                        X = X * 2;
                        file.WriteLine(X);
                    }
                    X = 1;
                }
            }

            

            Console.ReadLine();
        }
    }
}
