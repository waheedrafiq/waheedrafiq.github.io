﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace SpaceInvader
{
    class Rocket
    {
        Vector2 RocketPos;

        int MovementSpeed;

        public Rocket()
        {
            RocketPos = new Vector2();

            RocketPos.X = 512;
            RocketPos.Y = 725;

            MovementSpeed = 5;
        }

        public void Move(int MovementDiretion)
        {
            RocketPos.X = RocketPos.X + MovementSpeed * MovementDiretion;
        }

        public void SetXPos(int pos)
        {
            RocketPos.X = pos;
        }

        public int GetXPos()
        {
            return (int)RocketPos.X;
        }

        public void SetYPos(int pos)
        {
            RocketPos.Y = pos;
        }

        public int GetYPos()
        {
            return (int)RocketPos.Y;
        }

        public Vector2 GetPos()
        {
            return RocketPos;
        }
    }
}
