﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace SpaceInvader
{
    class Shield
    {
        Vector2 ShieldPos;

        public Shield(int XPos, int YPos)
        {
            ShieldPos = new Vector2(XPos, YPos);
        }
        
        public void SetPos(int XPos, int YPos)
        {
            ShieldPos.X = XPos;
            ShieldPos.Y = YPos;
        }

        public int GetXPos()
        {
            return (int)ShieldPos.X;
        }

        public int GetYPos()
        {
            return (int)ShieldPos.Y;
        }

        public Vector2 GetPos()
        {
            return ShieldPos;
        }
    }
}
