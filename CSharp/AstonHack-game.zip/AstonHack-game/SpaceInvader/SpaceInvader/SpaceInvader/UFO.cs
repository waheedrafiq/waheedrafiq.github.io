﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace SpaceInvader
{
    class UFO
    {
        Vector2 UFOPos;

        int MovementSpeed;

        bool Life;

        public UFO()
        {
            UFOPos = new Vector2();

            UFOPos.X = -116;
            UFOPos.Y = 50;

            MovementSpeed = 5;

            Life = true;
        }

        public void Move()
        {
            UFOPos.X = UFOPos.X + MovementSpeed;
        }

        public bool Alive()
        {
            return Life;
        }

        public void Die()
        {
            Life = false;
        }

        public void SetXPos(int pos)
        {
            UFOPos.X = pos;
        }

        public int GetXPos()
        {
            return (int)UFOPos.X;
        }

        public void SetYPos(int pos)
        {
            UFOPos.Y = pos;
        }

        public int GetYPos()
        {
            return (int)UFOPos.Y;
        }

        public Vector2 GetPos()
        {
            return UFOPos;
        }
    }
}
