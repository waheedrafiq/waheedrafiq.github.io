﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace SpaceInvader
{
    class Missile2
    {
        Vector2 Position;

        public Missile2(int XInitialPos, int YInitialPos)
        {
            Position = new Vector2(XInitialPos, YInitialPos);
        }

        public void SetPosition(int XInitialPos, int YInitialPos)
        {
            Position = new Vector2(XInitialPos, YInitialPos);
        }

        public void Move()
        {
            Position.Y = Position.Y + 4;
        }
        
        public Vector2 GetPosition()
        {
            return Position;
        }
    }
}
