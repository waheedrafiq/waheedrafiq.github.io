using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace SpaceInvader
{
    /// <summary>
    /// The Main type for the game
    /// </summary>
    public class SpaceInvaders : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        // Images
        Texture2D[] NewAlienIcons;

        Texture2D ourTeam;
        Texture2D astonHackEmblem;
        Texture2D mlhEmblem;
        Texture2D StarfieldImg;
        Texture2D InvaderImg1;
        Texture2D InvaderImg2;
        Texture2D InvaderImg3;
        Texture2D SuperInvaderImg;
        Texture2D RocketLauncherImg;
        Texture2D MissileImg;
        Texture2D Missile2Img;
        Texture2D ShieldPartImg;

        //Sounds
        SoundEffect ExplosionSound;
        SoundEffectInstance ExplosionSoundInstance;

        SoundEffect Explosion2Sound;
        SoundEffectInstance Explosion2SoundInstance;

        SoundEffect MissileSound;
        SoundEffectInstance MissileSoundInstance;

        SoundEffect InvaderSound;
        SoundEffectInstance InvaderSoundIstance;

        SoundEffect SuperInvaderSound;
        SoundEffectInstance SuperInvaderSoundInstance;

        // Game Round Tracker

        int Round;

        int websiteCounter;
        int invaderCounter;

        // Won and Lost Text

        string wonText, lostText;

        // Invaders & UFO
        Invader[,] Invaders;

        double[] rows = new double[10];

        string text;
        string[] lines;

        double[] numberOfInvaders = new double[10];

        string[] websiteName = new string[10];

        UFO UFO;

        // The Invaders' and their Missiles' Speed
        int iSpeed;
        int mSpeed;

        // Rocket & Missile
        Rocket Rocket;

        Missile MissileFired;
        Missile2[] InvaderMissile;

        // Shields
        Shield[, ,] Shields;

        // Game Variables
        int GameState;

        // used for specitic counts
        int K;
        int J;
        int Z;

        // used for getting the timer for different objects
        double Ticks1;
        double Ticks2;
        double Ticks3;
        
        // used to get random numbers to determine the firing invaders
        Random Random1;
        Random Random2;

        int PlayerScore;
        int Lives;

        // Fonts
        SpriteFont TitleFont;
        SpriteFont SubtitleFont;
        SpriteFont GameFont;
        SpriteFont ExtraFont;

        public SpaceInvaders()
        {
            graphics = new GraphicsDeviceManager(this);

            // Window Dimentions
            graphics.PreferredBackBufferWidth = 1024;
            graphics.PreferredBackBufferHeight = 768;
            graphics.ApplyChanges();

            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            GameState = 1;

            NewAlienIcons = new Texture2D[5];

            NewAlienIcons[0] = Texture2D.FromStream(GraphicsDevice, File.OpenRead("C:\\Users\\Taha\\Desktop\\AstonHack\\SpaceInvader\\SpaceInvader\\SpaceInvaderContent\\NewAlienIcon1.png"));
            NewAlienIcons[1] = Texture2D.FromStream(GraphicsDevice, File.OpenRead("C:\\Users\\Taha\\Desktop\\AstonHack\\SpaceInvader\\SpaceInvader\\SpaceInvaderContent\\NewAlienIcon2.png"));
            NewAlienIcons[2] = Texture2D.FromStream(GraphicsDevice, File.OpenRead("C:\\Users\\Taha\\Desktop\\AstonHack\\SpaceInvader\\SpaceInvader\\SpaceInvaderContent\\NewAlienIcon3.png"));

            Round = 0;

            iSpeed = 1;
            mSpeed = 100;

            PlayerScore = 0;

            Lives = 3;

            base.Initialize();
        }

        public void InitialiseGameVariables()
        {
            // Initialises everything at the beginning and after all invaders are dead

            Rocket = new Rocket();

            Lives = 3;

            MissileFired = null;

            InvaderMissile = new Missile2[5000];
            
            UFO = new UFO();

            K = 0;
            J = 0;
            Z = 0;

            Ticks1 = 0;
            Ticks2 = 0;
            Ticks3 = 0;

            Random1 = new Random();
            Random2 = new Random();

            // Sets all the invaders' positions and their quantity
            Invaders = new Invader[5, 11];

            // ----- Waheed ----- (Reading the number of invaders)
            
            text = System.IO.File.ReadAllText("D:\\AstonHack\\Data.txt");
            lines = text.Split('\n');

            int ifEven = 0;

            wonText = "";
            lostText = "";

            websiteCounter = 0;
            invaderCounter = 0;

            for (int i = 0; i < lines.Length; i++)
            {
                if (ifEven % 2 == 0)
                {
                    websiteName[websiteCounter] = lines[i];
                    websiteCounter++;
                    ifEven++;
                }
                else
                {
                    numberOfInvaders[invaderCounter] = Convert.ToInt32(lines[i]);
                    invaderCounter++;
                    ifEven++;
                }
            }

            for (int i = 0; i < websiteCounter; i++)
            {
                rows[i] = (numberOfInvaders[i] / 11) + 1;
            }

            int XPos = 217;
            int YPos = 100;
            for (int Count2 = 0; Count2 < rows[Round]; Count2++)
            {
                for (int Count = 0; Count < 11; Count++)
                {
                    Invaders[Count2, Count] = new Invader();
                    Invaders[Count2, Count].SetXPos(XPos);
                    Invaders[Count2, Count].SetYPos(YPos);

                    XPos = XPos + 52/*Invader's width*/ + 8;
                }
                YPos = YPos + 48;
                XPos = 212;
            }

            // Sets all the Shields' positions
            Shields = new Shield[4, 18, 6];

            XPos = 140;
            YPos = 675;

            for (int Count = 0; Count < 4; Count++)
            {
                for (int Count3 = 0; Count3 < 18; Count3++)
                {
                    for (int Count2 = 0; Count2 < 6; Count2++)
                    {
                        Shields[Count, Count3, Count2] = new Shield(XPos, YPos);

                        YPos += 5; /* A shield particles width*/
                    }
                    if (0 <= Count3 && Count3 <= 4)
                    {
                        YPos -= 5 * 7;
                    }

                    if (5 <= Count3 && Count3 <= 11)
                    {
                        YPos -= 5 * 6;
                    }

                    if (12 <= Count3 && Count3 <= 17)
                    {
                        YPos -= 5 * 5;
                    }

                    XPos += 5;
                }

                XPos += 125;
                YPos = 675;
            }
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);



            // Images
            
            ourTeam = Content.Load<Texture2D>("Representing");
            astonHackEmblem = Content.Load<Texture2D>("AstonHack");
            mlhEmblem = Content.Load<Texture2D>("MLH");

            StarfieldImg = Content.Load<Texture2D>("Starfield1024x768");

            InvaderImg1 = Content.Load<Texture2D>("Invader1");
            InvaderImg2 = Content.Load<Texture2D>("Invader2");
            InvaderImg3 = Content.Load<Texture2D>("Invader3");
            SuperInvaderImg = Content.Load<Texture2D>("SuperInvader");

            RocketLauncherImg = Content.Load<Texture2D>("Base");

            MissileImg = Content.Load<Texture2D>("bullet");
            Missile2Img = Content.Load<Texture2D>("InvaderMissile");

            ShieldPartImg = Content.Load<Texture2D>("ShieldParticle");

            // Fonts
            GameFont = Content.Load<SpriteFont>("GameFont");
            TitleFont = Content.Load<SpriteFont>("TitleFont");
            SubtitleFont = Content.Load<SpriteFont>("SubtitleFont");
            ExtraFont = Content.Load<SpriteFont>("ExtraFont");

            //Sounds
            ExplosionSound = Content.Load<SoundEffect>("explosion");
            ExplosionSoundInstance = ExplosionSound.CreateInstance();

            Explosion2Sound = Content.Load<SoundEffect>("explosion2");
            Explosion2SoundInstance = Explosion2Sound.CreateInstance();

            MissileSound = Content.Load<SoundEffect>("shoot");
            MissileSoundInstance = MissileSound.CreateInstance();

            InvaderSound = Content.Load<SoundEffect>("fastinvader1");
            InvaderSoundIstance = InvaderSound.CreateInstance();

            SuperInvaderSound = Content.Load<SoundEffect>("SuperInvaderSound");
            SuperInvaderSoundInstance = SuperInvaderSound.CreateInstance();
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Divides the game into different stages
            switch (GameState)
            {
                case 1: UpdateStarted(gameTime);
                    break;

                case 2: UpdateHelp(gameTime);
                    break;
                    
                case 3: UpdatePlaying(gameTime);
                    break;

                case 4: UpdateEnded(gameTime);
                    break;
            }

            base.Update(gameTime);
        }

        public void UpdateStarted(GameTime currentTime)
        {
            InitialiseGameVariables();

            Round = 0;

            iSpeed = 1;
            mSpeed = 100;

            PlayerScore = 0;

            Lives = 3;

            if (Keyboard.GetState().IsKeyDown(Keys.Enter))
            {
                GameState = 2;
            }
        }

        public void UpdateHelp(GameTime currentTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Space))
            {
                GameState = 3;
            }
        }

        public void UpdatePlaying(GameTime currentTime)
        {
            // --- Game End (WIN) ---
            bool InvaderFound = false;

            for (int Count2 = 0; Count2 < 5; Count2++)
            {
                for (int Count = 0; Count < 11; Count++)
                {
                    if (Invaders[Count2, Count] != null)
                    {
                        InvaderFound = true;
                        break;
                    }
                }
            }

            if (InvaderFound == false)
            {
                // Initiales everything only making the Invaders move and shoot faster
                iSpeed += 1;
                mSpeed -= 5;

                wonText += websiteName[Round];

                Round++;

                if (Round < websiteCounter - 1)
                {
                    InitialiseGameVariables();
                    GameState = 2;
                    return;
                }
                else
                {
                    GameState = 4;
                    return;
                }
            }

            // --- Game End (LOST) ---
            Rectangle rectRocket = new Rectangle((int)Rocket.GetXPos(), (int)Rocket.GetYPos(), RocketLauncherImg.Width, RocketLauncherImg.Height);

            for (int Count2 = 0; Count2 < 5; Count2++)
            {
                for (int Count = 0; Count < 11; Count++)
                {
                    if (Invaders[Count2, Count] != null)
                    {
                        Rectangle rectInvader = new Rectangle((int)Invaders[Count2, Count].GetXPos(), (int)Invaders[Count2, Count].GetYPos(), InvaderImg2.Width, InvaderImg2.Height);
                        
                        if (rectRocket.Intersects(rectInvader)) /* If the invaders touch the Rocket Launcher */
                        {
                            iSpeed += 1;
                            mSpeed -= 5;

                            lostText += websiteName[Round];

                            Round++;

                            if (Round < websiteCounter - 1)
                            {
                                InitialiseGameVariables();
                                GameState = 2;
                                ExplosionSoundInstance.Play();
                                return;
                            }
                            else
                            {
                                GameState = 4;
                                return;
                            }
                        }
                    }
                }
            }

            if (Lives == 0) /* If all lives are lost */
            {
                iSpeed += 1;
                mSpeed -= 5;

                lostText += websiteName[Round];

                Round += 1;

                if (Round < websiteCounter - 1)
                {
                    InitialiseGameVariables();
                    GameState = 2;
                    return;
                }
                else
                {
                    GameState = 4;
                    return;
                }
            }

            // Allows game to exit on users demand
            if (Keyboard.GetState().IsKeyDown(Keys.Q))
            {
                GameState = 4;
            }

            // --- Rocket Launcher's Movement ---
            if (Keyboard.GetState().IsKeyDown(Keys.Left))
            {
                Rocket.Move(-1);
            }

            if (Keyboard.GetState().IsKeyDown(Keys.Right))
            {
                Rocket.Move(1);
            }

            if (Rocket.GetPos().X < 134 - RocketLauncherImg.Width)
            {
                Rocket.SetXPos(134 - RocketLauncherImg.Width);
            }

            if (Rocket.GetPos().X > 890)
            {
                Rocket.SetXPos(890);
            }

            // --- Invaders' & UFO's Movement ---
            Ticks1 = Ticks1 + currentTime.ElapsedGameTime.TotalMilliseconds;
            Ticks2 = Ticks2 + currentTime.ElapsedGameTime.TotalMilliseconds;
            Ticks3 = Ticks3 + currentTime.ElapsedGameTime.TotalMilliseconds;

            // Playing invaders' movement sound
            if (Ticks1 > 150)
            {
                InvaderSoundIstance.Play();

                Ticks1 = 0;
            }

            // UFO's Movement
            if (UFO.Alive() == true && Ticks2 > 1250 && J == 0)
            {
                UFO.Move();

                J++;
            }

            if (UFO.Alive() == true && J == 1)
            {
                UFO.Move(); 
            }

            if (Ticks2 > 12500)
            {
                UFO.SetXPos(-116);

                Ticks2 = 0;
            }

            if (UFO.GetXPos() == -111)
            {
                SuperInvaderSoundInstance.Play();
            }

            //Invaders' Movement
            for (int Count2 = 0; Count2 < 5; Count2++)
            {
                for (int Count = 0; Count < 11; Count++)
                {
                    if (Invaders[Count2, Count] != null)
                    {
                        if (K <= 10)
                        {
                            Invaders[Count2, Count].MoveHorizontal(iSpeed);
                        }
                        // After a certain interval invaders' speed increases
                        else if (K > 10)
                        {
                            Invaders[Count2, Count].MoveHorizontal(iSpeed + 1);
                        }
                    }
                }
            }

            //Changing invaders' direction of movement and moving them down when they touch the margin
            int LeftMostInvader = 1024;
            int RightMostInvader = 0;

            for (int Count2 = 0; Count2 <= 4; Count2++)
            {
                for (int Count = 0; Count <= 10; Count++)
                {
                    if (Invaders[Count2, Count] != null && Invaders[Count2, Count].GetXPos() < LeftMostInvader)
                    {
                        LeftMostInvader = Invaders[Count2, Count].GetXPos(); /* Determining the left most invader */
                        break;
                    }
                }
            }

            for (int Count2 = 0; Count2 <= 4; Count2++)
            {
                for (int Count = 10; Count >= 0; Count--)
                {
                    if (Invaders[Count2, Count] != null && Invaders[Count2, Count].GetXPos() > RightMostInvader)
                    {
                        RightMostInvader = Invaders[Count2, Count].GetXPos(); /* Determining the right most invader */
                        break;
                    }
                }
            }

            if (LeftMostInvader < 134 - RocketLauncherImg.Width)
            {
                K++; /* Determines the interval to increase the Invaders' movement speed */

                for (int Count2 = 0; Count2 < 5; Count2++)
                {
                    for (int Count = 0; Count < 11; Count++)
                    {
                        if (Invaders[Count2, Count] != null)
                        {
                            Invaders[Count2, Count].SetMovDirection(+1);
                            Invaders[Count2, Count].MoveVertical(8);

                        }
                    }
                }
            }

            if (RightMostInvader > 890)
            {
                for (int Count2 = 0; Count2 < 5; Count2++)
                {
                    for (int Count = 0; Count < 11; Count++)
                    {
                        if (Invaders[Count2, Count] != null)
                        {
                            Invaders[Count2, Count].SetMovDirection(-1);
                            Invaders[Count2, Count].MoveVertical(8);
                        }
                    }
                }
            }

            // --- Firing Invaders ---
            for (int Count = 0; Count < Z; Count++)
            {
                if (InvaderMissile[Count] != null)
                {
                    InvaderMissile[Count].Move(); /* If exist: Moves the missiles down */
                }
            }

            if (Ticks3 > mSpeed)
            {
                int n = Random1.Next(0, 5);
                int m = Random2.Next(0, 11);

                if (Invaders[n, m] != null)
                {
                    InvaderMissile[Z] = new Missile2(Invaders[n, m].GetXPos(), Invaders[n, m].GetYPos()); /* Creates a new missile */

                    Z++;  
                }

                Ticks3 = 0;
            }

            for (int Count = 0; Count < Z; Count++)
            {
                if (InvaderMissile[Count] != null && InvaderMissile[Count].GetPosition().Y > 768) /* Checks if the missiles touch the bottom of the screen */
                {
                    InvaderMissile[Count] = null;
                }
            }

            // --- Hitting the Rocket Launcher ---
            Rectangle rectBase = new Rectangle((int)Rocket.GetXPos(), (int)Rocket.GetYPos() + 17, RocketLauncherImg.Width, 14); /* Creates a new rectangle for the Rkt Lnchr */

            for (int Count = 0; Count < Z; Count++)
            {
                if (InvaderMissile[Count] != null)
                {
                    Rectangle rectMissile2 = new Rectangle((int)InvaderMissile[Count].GetPosition().X + 4, (int)InvaderMissile[Count].GetPosition().Y + 12, 6, 21); /* Creates a new rectangle for each Missile */

                    if (rectBase.Intersects(rectMissile2))
                    {
                        InvaderMissile[Count] = null;

                        Lives -= 1;

                        Explosion2SoundInstance.Play();

                        break;
                    }
                }
            }

            // --- Firing Missiles ---
            if (MissileFired != null)
            {
                MissileFired.Move();
            }

            if (Keyboard.GetState().IsKeyDown(Keys.Space) && MissileFired == null)
            {
                MissileFired = new Missile(Rocket.GetXPos() + 28, 725);

                MissileSoundInstance.Play();
            }

            if (MissileFired != null && MissileFired.GetPosition().Y < 0)
            {
                MissileFired = null;
            }

            // --- Hitting Invaders and UFO with Missile ---
            if (MissileFired != null)
            {
                Rectangle rectMissile = new Rectangle((int)MissileFired.GetPosition().X, (int)MissileFired.GetPosition().Y, MissileImg.Width, MissileImg.Height);

                for (int Count2 = 0; Count2 < 5; Count2++)
                {
                    for (int Count = 0; Count < 11; Count++)
                    {
                        if (Invaders[Count2, Count] != null)
                        {
                            Rectangle rectInvader = new Rectangle(Invaders[Count2, Count].GetXPos(), Invaders[Count2, Count].GetYPos(), InvaderImg2.Width, InvaderImg2.Height);

                            if (rectMissile.Intersects(rectInvader))
                            {
                                Invaders[Count2, Count] = null;
                                MissileFired = null;

                                if (Count2 < 1)
                                {
                                    PlayerScore += 40;
                                }
                                else if (Count2 < 3)
                                {
                                    PlayerScore += 20;
                                }
                                else
                                {
                                    PlayerScore += 10;
                                }
                                
                                ExplosionSoundInstance.Play();

                                break;
                            }
                        }
                    }
                }

                Rectangle RectUFO = new Rectangle((int)UFO.GetXPos(), (int)UFO.GetYPos(), SuperInvaderImg.Width, SuperInvaderImg.Height);

                if (rectMissile.Intersects(RectUFO))
                {
                    MissileFired = null;

                    ExplosionSoundInstance.Play();

                    PlayerScore += 100;

                    UFO.Die();
                }
            }

            // --- Hitting the Shields ---

            // With Rocket Launcher's Missiles
            if (MissileFired != null)
            {
                Rectangle rectMissile = new Rectangle((int)MissileFired.GetPosition().X, (int)MissileFired.GetPosition().Y, MissileImg.Width, MissileImg.Height);

                for (int Count = 0; Count < 4; Count++)
                {
                    for (int Count3 = 0; Count3 < 18; Count3++)
                    {
                        for (int Count2 = 0; Count2 < 6; Count2++)
                        {
                            if (Shields[Count, Count3, Count2] != null)
                            {
                                Rectangle rectShield = new Rectangle(Shields[Count, Count3, Count2].GetXPos(), Shields[Count, Count3, Count2].GetYPos(), 5, 5);

                                if (rectMissile.Intersects(rectShield))
                                {
                                    MissileFired = null;

                                    Shields[Count, Count3, Count2] = null;
                                }
                            }
                        }
                    }
                }
            }

            // With Invaders' Missiles
            for (int Count = 0; Count < Z; Count++)
            {
                if (InvaderMissile[Count] != null)
                {
                    Rectangle rectMissile2 = new Rectangle((int)InvaderMissile[Count].GetPosition().X + 4, (int)InvaderMissile[Count].GetPosition().Y, 6, Missile2Img.Height);

                    for (int Count1 = 0; Count1 < 4; Count1++)
                    {
                        for (int Count3 = 0; Count3 < 18; Count3++)
                        {
                            for (int Count2 = 0; Count2 < 6; Count2++)
                            {
                                if (Shields[Count1, Count3, Count2] != null)
                                {
                                    Rectangle rectShield = new Rectangle(Shields[Count1, Count3, Count2].GetXPos(), Shields[Count1, Count3, Count2].GetYPos(), 5, 5);

                                    if (rectMissile2.Intersects(rectShield))
                                    {
                                        InvaderMissile[Count] = null;

                                        Shields[Count1, Count3, Count2] = null;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // With Invaders
            for (int Count11 = 0; Count11 < 5; Count11++)
            {
                for (int Count12 = 0; Count12 < 11; Count12++)
                {
                    if (Invaders[Count11, Count12] != null)
                    {
                        Rectangle rectInvader = new Rectangle(Invaders[Count11, Count12].GetXPos(), Invaders[Count11, Count12].GetYPos(), InvaderImg2.Width, InvaderImg2.Height);

                        for (int Count21 = 0; Count21 < 4; Count21++)
                        {
                            for (int Count23 = 0; Count23 < 18; Count23++)
                            {
                                for (int Count22 = 0; Count22 < 6; Count22++)
                                {
                                    if (Shields[Count21, Count23, Count22] != null)
                                    {
                                        Rectangle rectShield = new Rectangle(Shields[Count21, Count23, Count22].GetXPos(), Shields[Count21, Count23, Count22].GetYPos(), 5, 5);

                                        if (rectInvader.Intersects(rectShield))
                                        {
                                            Shields[Count21, Count23, Count22] = null;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        public void UpdateEnded(GameTime currentTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Escape))
            {
                this.Exit();
            }

            if (Keyboard.GetState().IsKeyDown(Keys.R))
            {
                GameState = 1;
            }
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            switch (GameState)
            {
                case 1: DrawStarted(gameTime);
                    break;

                case 2: DrawHelp(gameTime);
                    break;

                case 3: DrawPlaying(gameTime);
                    break;

                case 4: DrawEnded(gameTime);
                    break;
            }

            base.Draw(gameTime);
        }

        public void DrawStarted(GameTime currentTime)
        {
            spriteBatch.Begin();

            spriteBatch.Draw(StarfieldImg, Vector2.Zero, Color.White);

            string Title = String.Format("Space Invaders");
            string coTitle = String.Format("againts popular websites");
            string SubTitle = String.Format("Press ENTER to play");

            spriteBatch.DrawString(TitleFont, Title, new Vector2(100, 50), Color.DarkOrange);
            spriteBatch.DrawString(SubtitleFont, coTitle, new Vector2(200, 170), Color.Yellow);
            spriteBatch.DrawString(SubtitleFont, SubTitle, new Vector2(255, 500), Color.DarkRed);

            spriteBatch.Draw(ourTeam, new Vector2(200, 300), Color.White);
            spriteBatch.Draw(astonHackEmblem, new Vector2(240, 600), Color.White);
            spriteBatch.Draw(mlhEmblem, new Vector2(490, 625), Color.White);

            spriteBatch.End();
        }

        public void DrawHelp(GameTime currentTime)
        {
            spriteBatch.Begin();

            spriteBatch.Draw(StarfieldImg, Vector2.Zero, Color.White);

            string Points1 = string.Format("You Shall be fighting againts:");
            string Subtitle = string.Format("Press SPACE to begin!");

            spriteBatch.DrawString(SubtitleFont, Points1, new Vector2(100, 100), Color.White);
            spriteBatch.DrawString(ExtraFont, websiteName[Round], new Vector2(275, 200), Color.CadetBlue); 
            spriteBatch.DrawString(SubtitleFont, Subtitle, new Vector2(230, 600), Color.White);

            string MoveLeft = string.Format("Move left using LEFT ARROW KEY");
            string MoveRight = string.Format("Move right using RIGHT ARROW KEY");
            string Fire = string.Format("Fire using SPACE");
            string Quit = string.Format("To quit press Q");

            spriteBatch.DrawString(GameFont, MoveLeft, new Vector2(347, 495), Color.White);
            spriteBatch.DrawString(GameFont, MoveRight, new Vector2(337, 520), Color.White);
            spriteBatch.DrawString(GameFont, Fire, new Vector2(428, 545), Color.White);
            spriteBatch.DrawString(GameFont, Quit, new Vector2(433, 570), Color.White);

            spriteBatch.Draw(NewAlienIcons[Round], new Vector2(240, 208), Color.White);

            spriteBatch.End();
        }

        public void DrawPlaying(GameTime currentTime)
        {
            spriteBatch.Begin();

            // --- Drawing the Background ---
            spriteBatch.Draw(StarfieldImg, Vector2.Zero, Color.White);
            
            // --- Drawing the Rocket Launcher ---
            spriteBatch.Draw(RocketLauncherImg, Rocket.GetPos(), Color.White);

            // --- Drawing the Missiles ---
            if (MissileFired != null)
            {
                Vector2 MissilePos = new Vector2(MissileFired.GetPosition().X, MissileFired.GetPosition().Y - MissileImg.Height);

                spriteBatch.Draw(MissileImg, MissilePos, Color.White);
            }

            for (int Count = 0; Count < Z; Count++)
            {
                if (InvaderMissile[Count] != null)
                {
                    Vector2 Missile2Pos = new Vector2(InvaderMissile[Count].GetPosition().X, InvaderMissile[Count].GetPosition().Y);

                    spriteBatch.Draw(Missile2Img, Missile2Pos, Color.DarkRed);
                }
            }

            // --- Drawing the Invaders ---
            for (int Count2 = 0; Count2 < 5; Count2++)
            {
                for (int Count = 0; Count < 11; Count++)
                {
                    if (Invaders[Count2, Count] != null)
                    {
                        spriteBatch.Draw(NewAlienIcons[Round], Invaders[Count2, Count].GetPos(), Color.Violet);
                    }
                }
            }

            // --- Drawing the Shields ---
            for (int Count = 0; Count < 4; Count++)
            {
                for (int Count3 = 0; Count3 < 18; Count3++)
                {
                    for (int Count2 = 0; Count2 < 6; Count2++)
                    {
                        if (Shields[Count, Count3, Count2] != null)
                        {
                            spriteBatch.Draw(ShieldPartImg, Shields[Count, Count3, Count2].GetPos(), Color.White);
                        }
                    }
                }
            }

            // --- Drawing the UFO ---
            if (UFO.Alive() == true)
            {
                spriteBatch.Draw(SuperInvaderImg, UFO.GetPos(), Color.White);
            }

            // --- Drawing Score and Lives ---
            string ScoreText = String.Format("Score = {0}", PlayerScore);

            spriteBatch.DrawString(GameFont, ScoreText, new Vector2(10,10), Color.White);

            string LivesText = String.Format("Lives:");

            spriteBatch.DrawString(GameFont, LivesText, new Vector2(600, 10), Color.White);

            int M = 680;

            for (int Count = 1; Count <= Lives; Count++)
            {
                spriteBatch.Draw(RocketLauncherImg, new Vector2(M, 10), Color.White);

                M += 69;
            }

            spriteBatch.End();
        }

        public void DrawEnded(GameTime currentTime)
        {
            spriteBatch.Begin();

            spriteBatch.Draw(StarfieldImg, Vector2.Zero, Color.White);

            string Thanks = String.Format("Thank you for playing!");
            string Score = String.Format("Score: ");
            string Quit = String.Format("Press ESC to quit");

            spriteBatch.DrawString(SubtitleFont, Thanks, new Vector2(200, 150), Color.White);
            spriteBatch.DrawString(SubtitleFont, Score + PlayerScore, new Vector2(400, 230), Color.White);
            spriteBatch.DrawString(GameFont, Quit, new Vector2(415, 525), Color.White);

            spriteBatch.End();
        }
    }
}
