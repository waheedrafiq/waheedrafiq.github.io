﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismExample
{ // Example of Polymorphism 
     class Shape // create a class example shape 
     {
         public virtual  void Draw()
         {
             Console.WriteLine("You are in the virtual method of Drawing");
         }

     }

    // Circle is base , Shape is derived
    class Circle : Shape // the shape you will have is circle 
    {// remember Polymorphism is acheived by creating a base class  with Virtual method.
        

       public Circle()
        {
            Console.WriteLine("I am a Circle");
        }

       public override void Draw()  // then creating derivied class that override the behaviour of the base class
           // virtual method. Notice Draw() in virtual method and in this we just over ridded it. 
       {
           Console.Write("Drawing a Circle....."); 
          Console.ForegroundColor= ConsoleColor.Green;
         Console.WriteLine("\n");
         Console.WriteLine("\t"+"   ====");
         Console.WriteLine("\t"+" ==     ==");
         Console.WriteLine("\t"+" ==     ==");
         Console.WriteLine("\t"+"   =====    ");
         Console.ForegroundColor= ConsoleColor.White; 


       }

    }// end of Circle Class 

    class Rectangle : Shape
    {

        public Rectangle()
        {
            Console.WriteLine("\nI am a Retangle ....");
        }

        public override void Draw()
        {
            Console.Write("\nDrawing a Rectangle ....");
            Console.WriteLine("\n");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("\t");
            // draw line vertical 
            for (int i = 0; i <= 8; i++)
            {
                Console.Write("-");
            }
            Console.WriteLine("\t");
            // Draw line horiztal 
            for (int i = 0; i < 4; i++)
            {
                
                Console.WriteLine("\t" + "|" + "\t" + "|");

            }
            // draw line vertical bottom to complete the shape
            Console.Write("\t");
            for (int i = 0; i <= 8; i++)
            {
                Console.Write("-");
            }
            

        }
    }// end of Rectangle 





    class Program
    {
        static void Main(string[] args)
        {

            List<Shape> myShape = new List<Shape>(); // note synax for list<> ends with (); 

            myShape.Add(new Circle());// except Shape object , but get a circle
            myShape.Add(new Rectangle()); // Except a shape object but get a Rectangle



         foreach (Shape item in myShape)
	{
		 item.Draw(); // Draw that object
	}
            Console.ReadKey(); // wait for user to press key to exit.
			 
			
        }
    }
}
