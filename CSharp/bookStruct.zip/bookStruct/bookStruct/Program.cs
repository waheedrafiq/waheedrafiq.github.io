﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bookStruct
{
    class Program
    {
        #region Struct declare
        public struct BookInfo
        {
            public string Title;
            public string category;
            public string Author;
            public int numPages;
            public int currentPage;
            public double ISBN;
            public string CoverStyle;

            #region 1st Bookinfo Constructor declared
            public BookInfo(string title, string category, string author, int numPages, int currentPage, double isbn, string cover)
            {// intisise struct variables. 

                this.Title = title;
                this.category = category;
                this.Author = author;
                this.numPages = numPages;
                this.currentPage = currentPage;
                this.ISBN = isbn;
                this.CoverStyle = cover;
            }
            #endregion

            #region method for turning pages
            public void nextpage()
            {
                if (currentPage != numPages)
                {
                    currentPage++;
                    Console.WriteLine("Current page is now: " + this.currentPage);
                }
                else
                {
                    Console.WriteLine("At end of book. ");
                }
            }
            #endregion

            public void prevPage()
            {
                if (currentPage != 1)
                {
                    currentPage--;
                    Console.WriteLine("Current Page is now: " + this.currentPage);
                }
                else
                {
                    Console.WriteLine("At the beginning of the book.");
                }
            }

        }// end of Struct 
        #endregion
       






        static void Main(string[] args)
        {
            BookInfo myBook = new BookInfo("MCSD Certification ToolKit (Exam 70-483)", "Certification", "Covaci Tiberiu", 648, 1, 81118612095, "Soft Cover");

            Console.WriteLine(myBook.Title);
            Console.WriteLine(myBook.category);
            Console.WriteLine(myBook.Author);
            Console.WriteLine(myBook.numPages);
            Console.WriteLine(myBook.currentPage);
            Console.WriteLine(myBook.ISBN);
            Console.WriteLine(myBook.CoverStyle);

            myBook.nextpage();
            myBook.prevPage();

            Console.ReadKey();

        }
    }
}
