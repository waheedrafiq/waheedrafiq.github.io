﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bookStruct
{
    class BookInfo
    {
        #region Struct declare
        public struct Book
        {
            public string Title;
            public string category;
            public string Author;
            public int numPages;
            public int currentPage;
            public double ISBN;
            public string CoverStyle;

            #region 1st Bookinfo Constructor declared
            public Book(string title, string category, string author, int numPages, int currentPage, double isbn, string cover)
            {// intisise struct variables. 

                this.Title = title;
                this.category = category;
                this.Author = author;
                this.numPages = numPages;
                this.currentPage = currentPage;
                this.ISBN = isbn;
                this.CoverStyle = cover;
            }
            #endregion

            #region method for turning pages
            public void nextpage()
            {
                if(currentPage != numPages)
                {
                    currentPage++;
                    Console.WriteLine("Current page is now: " + this.currentPage);
                }
                else
                {
                    Console.WriteLine("At end of book. ");
                }
            }
            #endregion

            public void prevPage()
            {
                if (currentPage != 1)
                {
                    currentPage--;
                    Console.WriteLine("Current Page is now: " + this.currentPage);
                }
                else
                {
                    Console.WriteLine("At the beginning of the book.");
                }
            }

        }// end of Struct 
            #endregion
    }
}

