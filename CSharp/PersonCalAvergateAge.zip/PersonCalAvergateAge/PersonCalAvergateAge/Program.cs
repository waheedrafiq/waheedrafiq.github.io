﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace PersonCalAvergateAge
{
    class Program
    {
        private static  int result=0;
        private static int index = 0;
        static void Main(string[] args)
        {
            string sAppPath = System.AppDomain.CurrentDomain.BaseDirectory;
            Debug.WriteLine("your path is: " + sAppPath);
            string csvFilePath = sAppPath +"People.csv";
            result = GetAverageAge(csvFilePath);
            Console.WriteLine("The average value is :" + result);
            Console.ReadKey();

        }

        private static int GetAverageAge(string csvFilePath)
        {
            // Your code here ...
            using (var reader = new StreamReader(csvFilePath))
            {
                List<string> people = new List<string>();
          
              
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var part = line.Split(',');// To Separate values 

                   string fieldSurname =part[0];
                   string fieldforename = part[1];
                   part = line.Split('/');
                   string fieldYear = part[2];
                 
                   string field = part[part.Length - 1];
                    people.Add(fieldSurname);
                    people.Add(fieldforename);
                    people.Add(fieldYear);
                    result += int.Parse( fieldYear);
                    index++;
                    
                }
                Debug.WriteLine("No more Data found: " );

                 result = result / index;
                return result; // return the average value 

            }// end of encapsulation       
        }// end of method 
    }// end of class 

}// end of namespace
