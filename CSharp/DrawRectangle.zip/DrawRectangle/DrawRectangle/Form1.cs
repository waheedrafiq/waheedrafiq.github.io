﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace DrawRectangle
{
    public partial class frmRectangle : Form
    {
        public frmRectangle()
        {
            InitializeComponent();
        }
        int SideA = 0;
        int SideB = 0;
        int SideC =100;
        int SideD= 200;
        int SqUnit;
        private void btnRectangle_Click(object sender, EventArgs e)
        {
 

 
           
            Pen blue = new Pen(Color.Blue, 3);
            System.Drawing.SolidBrush myBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Red);
            System.Drawing.Graphics frmRectangle;
            frmRectangle = this.CreateGraphics();


            SideA = Int16.Parse(txtA.Text);
            SideB = Int16.Parse(txtB.Text);
            SideC = Int16.Parse(txtC.Text);
            SideD = Int16.Parse(txtD.Text);
           

            frmRectangle.FillRectangle(myBrush, new Rectangle(SideA, SideB, SideC, SideD));

            SqUnit= SideC * SideD;
            lblSqUnit.Text = SqUnit.ToString();


            lblSideA.Text = SideA.ToString();
            lblSideB.Text = SideB.ToString();
            lblSideC.Text = SideC.ToString();
            lblSideD.Text = SideD.ToString(); 
            // reset to default values
            SideA = 10;
            SideB = 10;
            SideC = 10;
            SideD = 10; 

           
           

            myBrush.Dispose();
            frmRectangle.Dispose();
          
        }
    }
}
