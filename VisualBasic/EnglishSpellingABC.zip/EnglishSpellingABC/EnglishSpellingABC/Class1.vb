﻿

Public Class Class1
    ' Declare Global Variable

    Public Shared GUserinput As String
    Public Shared Cancel As Boolean
    Public Shared StoreWrongAnswer(5) As String

    
End Class
