/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library;

/**
 *
 * @author waheedrafiq
 */

interface LibraryManager{
      
    public final String baseclass ="LibraryManager";
      public void RegisterPerson(String fullname,String emailaddress,String passwrd);
   
    
      //public void NoticeBoard();
    
}
