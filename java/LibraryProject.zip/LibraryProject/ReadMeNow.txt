Working Progress... please bare with , I shall nail this project by 

Saturday 9pm 