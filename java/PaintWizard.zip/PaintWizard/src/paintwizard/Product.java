/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paintwizard;

/**
 *
 * @author MobileLaptopWR
 */
public class Product extends WallMathsWorkOut
{
    
    
    private double  litres,SqrFootage , PaintTinUsed, PaintCost, waste;
    public double  CheapoMax, AverageJoes, DuluxourousPaints;

    public double getLitres() {
        return litres;
    }

    public void setLitres(double litres) {
        this.litres = litres;
    }

    public double getSqrFootage() {
        return SqrFootage;
    }

    public void setSqrFootage(double SqrFootage) {
        this.SqrFootage = SqrFootage;
    }

    public double getPaintTinUsed() {
        return PaintTinUsed;
    }

    public void setPaintTinUsed(double PaintTinUsed) {
        this.PaintTinUsed = PaintTinUsed;
    }

    public double getPaintCost() {
        return PaintCost;
    }

    public void setPaintCost(double PaintCost) {
        this.PaintCost = PaintCost;
    }

    public double getWaste() {
        return waste;
    }

    public void setWaste(double waste) {
        this.waste = waste;
    }

    public double getCheapoMax() {
        return CheapoMax;
    }

    public void setCheapoMax(double CheapoMax) {
        this.CheapoMax = CheapoMax;
    }

    public double getAverageJoes() {
        return AverageJoes;
    }

    public void setAverageJoes(double AverageJoes) {
        this.AverageJoes = AverageJoes;
    }

    public double getDuluxourousPaints() {
        return DuluxourousPaints;
    }

    public void setDuluxourousPaints(double DuluxourousPaints) {
        this.DuluxourousPaints = DuluxourousPaints;
    }

    

  

    
     
      


    
}// end of Products class 


