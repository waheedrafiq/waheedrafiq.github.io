
Use EPOSv2
GO

INSERT INTO tbl_Users (Users_Fname,Users_Sname,Users_Email,Users_Username,Users_ImagePath)
VALUES ('BOB','JOES','BJ@EMAIL.COM','bj','/App_Data/Images/Users/bj.jpg')
