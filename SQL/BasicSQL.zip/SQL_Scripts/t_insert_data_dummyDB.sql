-- test insert into dummy data  random data 

USE dummy

GO

INSERT INTO [dbo].[dummyTest](dum_Fname)
VALUES ('Joe');

INSERT INTO [dbo].[dummyTest](dum_Fname)
VALUES ('Bob');

INSERT INTO [dbo].[dummyTest](dum_Fname)
VALUES ('Waheed');