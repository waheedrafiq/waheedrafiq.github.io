﻿CREATE TABLE [dbo].[tbl_PIM]
(
	PIM_ID int IDENTITY(1,1) PRIMARY KEY,
	PIM_Fname varchar(100),
	PIM_Sname varchar(100),
	PIM_Email varchar(100),
	PIM_Image varchar(100)

)
