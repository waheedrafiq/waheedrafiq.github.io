USE [master]
GO

/****** Object:  Database [sales]    Script Date: 01/02/2015 09:50:26 ******/
DROP DATABASE [sales]
GO

